"""Alternative nominal formation controllers (control baselines).

  C0  ConsensusController (swarmsec.nominal)      relative-position consensus
  C1  RigidityController                           distance-based (rigidity) formation
  C2  C0 + HOCBF-QP collision filter               (the default filter)
  C3  C1 + collision AND connectivity HOCBF-QP     formation + collision + connectivity

All share compute(positions, velocities, weights, robust, self_pos, self_vel) so
the simulator, attacks and defenses are controller-agnostic.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .graph import neighbours_of_pt
from .nominal import ConsensusController


@dataclass
class RigidityController:
    """u_i = -kp * mean_j[(||p_ij|| - d_ij) p_ij/||p_ij||] - kv * mean_j[v_i - v_j] + mission.

    d_ij = ||delta_i - delta_j|| are the inter-agent distances of the target
    formation (distance-based / rigidity formation control).
    """

    kp: float = 1.2
    kv: float = 1.4
    kv_mission: float = 1.0
    neighbor_radius: float = 6.0
    offsets: np.ndarray = None
    mission_velocity: np.ndarray = None

    def __post_init__(self):
        if self.mission_velocity is None:
            self.mission_velocity = np.zeros(3)
        self.mission_velocity = np.asarray(self.mission_velocity, float)

    def compute(self, positions, velocities, weights=None, robust=None,
                self_pos=None, self_vel=None):
        n = positions.shape[0]
        sp = positions if self_pos is None else self_pos
        sv = velocities if self_vel is None else self_vel
        u = np.zeros((n, 3))
        for i in range(n):
            idx = neighbours_of_pt(sp[i], i, positions, self.neighbor_radius)
            mission = self.kv_mission * (self.mission_velocity - sv[i])
            if len(idx) == 0:
                u[i] = mission
                continue
            w = np.ones(len(idx)) if weights is None else weights[i, idx]
            p_ij = sp[i] - positions[idx]
            dist = np.maximum(np.linalg.norm(p_ij, axis=1), 1e-6)
            d_des = np.linalg.norm(self.offsets[i] - self.offsets[idx], axis=1)
            pos_terms = ((dist - d_des) / dist)[:, None] * p_ij
            vel_terms = sv[i] - velocities[idx]
            e = ConsensusController._aggregate(pos_terms, w, robust)
            ve = ConsensusController._aggregate(vel_terms, w, robust)
            u[i] = -self.kp * e - self.kv * ve + mission
        return u


# ---------------------------------------------------------------------------
# Classic swarm controllers (control baselines C4..C7)
# ---------------------------------------------------------------------------

def _w(weights, i, idx):
    return np.ones(len(idx)) if weights is None else weights[i, idx]


@dataclass
class FlockingController:
    """C4: Olfati-Saber flocking (Algorithm 2: alpha-lattice + velocity consensus + navigation).

    Agents self-organise into a lattice of spacing d with no assigned slots:
        u_i = c1 sum_j phi_a(||q_j-q_i||_s) n_ij + c2 sum_j a_ij (p_j-p_i) + c_mt (v_m - p_i)
    (sigma-norm, bump function and action function as in Olfati-Saber, TAC 2006).
    """

    d: float = 4.0
    r_factor: float = 1.5
    eps: float = 0.1
    h: float = 0.9      # bump plateau: keep full interaction out to the sensing edge (avoids fragmentation)
    a: float = 5.0
    b: float = 5.0
    c1: float = 0.6       # tuned: c1 >= 1.5 merges agents in discrete time (see scripts/sim/tune_flock.py)
    c2: float = 2.4
    c_mt: float = 1.0
    neighbor_radius: float = 6.0
    offsets: np.ndarray = None
    mission_velocity: np.ndarray = None
    spacing_scale: float = 1.0

    def __post_init__(self):
        if self.mission_velocity is None:
            self.mission_velocity = np.zeros(3)
        self.mission_velocity = np.asarray(self.mission_velocity, float)
        self._c = abs(self.a - self.b) / np.sqrt(4 * self.a * self.b)

    def _sig(self, z):
        return (np.sqrt(1.0 + self.eps * z * z) - 1.0) / self.eps

    def _bump(self, z):
        return np.where(z < self.h, 1.0, np.where(z < 1.0, 0.5 * (1 + np.cos(np.pi * (z - self.h) / (1 - self.h))), 0.0))

    def _phi(self, z):
        sg = lambda x: x / np.sqrt(1 + x * x)
        return 0.5 * ((self.a + self.b) * sg(z + self._c) + (self.a - self.b))

    def formation_error(self, positions):
        """Lattice error: mean |d_ij - d| over pairs closer than the interaction range."""
        D = np.linalg.norm(positions[:, None] - positions[None], axis=2)
        iu = np.triu_indices(len(positions), 1)
        d = D[iu]
        near = d <= min(self.r_factor * self.d * self.spacing_scale, self.neighbor_radius)
        return float(np.mean(np.abs(d[near] - self.d * self.spacing_scale))) if near.any() else float("nan")

    def compute(self, positions, velocities, weights=None, robust=None, self_pos=None, self_vel=None):
        n = positions.shape[0]
        sp = positions if self_pos is None else self_pos
        sv = velocities if self_vel is None else self_vel
        d = self.d * self.spacing_scale
        r = min(self.r_factor * d, self.neighbor_radius)
        r_a, d_a = self._sig(r), self._sig(d)
        u = np.zeros((n, 3))
        for i in range(n):
            idx = neighbours_of_pt(sp[i], i, positions, self.neighbor_radius)
            u[i] = self.c_mt * (self.mission_velocity - sv[i])
            if len(idx) == 0:
                continue
            w = _w(weights, i, idx)
            diff = positions[idx] - sp[i]
            dist = np.linalg.norm(diff, axis=1)
            z = self._sig(dist)
            nij = diff / np.sqrt(1.0 + self.eps * dist * dist)[:, None]
            phi_a = self._bump(z / r_a) * self._phi(z - d_a)
            aij = self._bump(z / r_a)
            u[i] += self.c1 * (w[:, None] * phi_a[:, None] * nij).sum(axis=0)
            u[i] += self.c2 * (w[:, None] * aij[:, None] * (velocities[idx] - sv[i])).sum(axis=0)
        return u


@dataclass
class LeaderFollowerController:
    """C5: leader tracks the mission; followers hold their formation slot relative to the leader.

    u_i = -kp (p_i - p_L - (delta_i - delta_L)) - kv (v_i - v_L)       (followers)
    u_L = kv_m (v_mission - v_L)                                        (leader)
    A defense that down-weights the leader attenuates the followers' coupling.
    """

    leader: int = 0
    kp: float = 1.2
    kv: float = 1.8
    kv_mission: float = 1.0
    neighbor_radius: float = 6.0
    offsets: np.ndarray = None
    mission_velocity: np.ndarray = None

    def __post_init__(self):
        if self.mission_velocity is None:
            self.mission_velocity = np.zeros(3)
        self.mission_velocity = np.asarray(self.mission_velocity, float)

    def compute(self, positions, velocities, weights=None, robust=None, self_pos=None, self_vel=None):
        n = positions.shape[0]
        sp = positions if self_pos is None else self_pos
        sv = velocities if self_vel is None else self_vel
        L = self.leader
        u = np.zeros((n, 3))
        u[L] = self.kv_mission * (self.mission_velocity - sv[L])
        for i in range(n):
            if i == L:
                continue
            g = 1.0 if weights is None else float(weights[i, L])
            e = (sp[i] - positions[L]) - (self.offsets[i] - self.offsets[L])
            u[i] = g * (-self.kp * e - self.kv * (sv[i] - velocities[L])) + (1 - g) * self.kv_mission * (self.mission_velocity - sv[i])
        return u


@dataclass
class BoidsController:
    """C6: Reynolds boids (separation + alignment + cohesion) steered by the mission velocity."""

    d: float = 4.0
    w_sep: float = 2.5
    w_ali: float = 1.0
    w_coh: float = 0.35
    kv_mission: float = 1.0
    neighbor_radius: float = 6.0
    offsets: np.ndarray = None
    mission_velocity: np.ndarray = None
    spacing_scale: float = 1.0

    def __post_init__(self):
        if self.mission_velocity is None:
            self.mission_velocity = np.zeros(3)
        self.mission_velocity = np.asarray(self.mission_velocity, float)

    def formation_error(self, positions):
        D = np.linalg.norm(positions[:, None] - positions[None], axis=2)
        iu = np.triu_indices(len(positions), 1)
        d = D[iu]
        near = d <= self.neighbor_radius
        return float(np.mean(np.abs(d[near] - self.d * self.spacing_scale))) if near.any() else float("nan")

    def compute(self, positions, velocities, weights=None, robust=None, self_pos=None, self_vel=None):
        n = positions.shape[0]
        sp = positions if self_pos is None else self_pos
        sv = velocities if self_vel is None else self_vel
        r_sep = self.d * self.spacing_scale
        u = np.zeros((n, 3))
        for i in range(n):
            idx = neighbours_of_pt(sp[i], i, positions, self.neighbor_radius)
            u[i] = self.kv_mission * (self.mission_velocity - sv[i])
            if len(idx) == 0:
                continue
            w = _w(weights, i, idx)
            diff = sp[i] - positions[idx]
            dist = np.maximum(np.linalg.norm(diff, axis=1), 1e-6)
            close = dist < r_sep
            sep = (w[:, None] * close[:, None] * (r_sep / dist - 1.0)[:, None] * diff / dist[:, None]).sum(axis=0)
            wn = w / max(w.sum(), 1e-9)
            ali = (wn[:, None] * (velocities[idx] - sv[i])).sum(axis=0)
            coh = (wn[:, None] * (positions[idx] - sp[i])).sum(axis=0)
            u[i] += self.w_sep * sep + self.w_ali * ali + self.w_coh * coh
        return u


@dataclass
class VirtualStructureController:
    """C7: virtual structure. A reference frame advances with the mission velocity and every UAV
    tracks its own slot in it (no neighbour coupling, so a compromised UAV only reaches the others
    through the safety filter)."""

    kp: float = 1.0
    kv: float = 1.8
    neighbor_radius: float = 6.0
    dt: float = 0.05
    offsets: np.ndarray = None
    mission_velocity: np.ndarray = None
    spacing_scale: float = 1.0

    def __post_init__(self):
        if self.mission_velocity is None:
            self.mission_velocity = np.zeros(3)
        self.mission_velocity = np.asarray(self.mission_velocity, float)
        self._ref = None

    def compute(self, positions, velocities, weights=None, robust=None, self_pos=None, self_vel=None):
        sp = positions if self_pos is None else self_pos
        sv = velocities if self_vel is None else self_vel
        if self._ref is None:
            self._ref = sp.mean(axis=0).copy()
        self._ref = self._ref + self.mission_velocity * self.dt
        target = self._ref + self.offsets * self.spacing_scale
        return -self.kp * (sp - target) - self.kv * (sv - self.mission_velocity)


CONTROLLER_NAMES = {
    "C0": "Consensus (relative position)", "C1": "Rigidity (distance-based)",
    "C3": "Rigidity + connectivity CBF", "C4": "Olfati-Saber flocking",
    "C5": "Leader-follower", "C6": "Reynolds boids", "C7": "Virtual structure",
}


def make_controller(name: str, **kw):
    name = name.upper()
    if name in ("C0", "C2"):
        return ConsensusController(**kw), None
    if name == "C1":
        return RigidityController(**kw), None
    if name == "C3":
        return RigidityController(**kw), 5.9        # connectivity radius (< 6 m sensing)
    if name == "C4":
        kw.pop("kp", None); kw.pop("kv", None)
        return FlockingController(**kw), None
    if name == "C5":
        kw.pop("kp", None); kw.pop("kv", None)
        return LeaderFollowerController(**kw), None
    if name == "C6":
        kw.pop("kp", None); kw.pop("kv", None)
        return BoidsController(**kw), None
    if name == "C7":
        kw.pop("kp", None); kw.pop("kv", None)
        return VirtualStructureController(**kw), None
    raise ValueError(f"unknown controller {name!r}")
