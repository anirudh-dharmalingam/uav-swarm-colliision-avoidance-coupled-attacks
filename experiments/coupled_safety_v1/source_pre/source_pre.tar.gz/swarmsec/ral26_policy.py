"""Per-agent RAL26 safety policies: corrected baseline D24R and the D26 RAVS supervisor + ablations.

One `AgentPolicy` instance lives inside ONE UAV's own controller process.  Its inputs are only what
that UAV has onboard: its own PX4 estimate, the packets its own FANET receiver delivered (with local
receive times), its own energy estimate and the shared mission plan.  It never sees evaluator truth.

D24R and every D26 variant share the SAME hard rows (ral26_core.certificate_rows), the same actuator
ball, the same bounds object and the same emergency policy (the max-reserve command u* when no hard
certificate exists).  They differ only in the supervisor:

  variant        packet-age model           mission relax   link refresh   energy return
  D24R_STATIC    fixed worst-case age       no              no             no
  D24R_AOI       measured AoI (same as D26) no              no             no
  D26_NOAOI      fixed nominal age          yes             yes            yes
  D26_NOBATT     measured AoI               yes             yes            no
  D26_NOLINK     measured AoI               yes             no             yes
  D26 (full)     measured AoI               yes             yes            yes
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field

import numpy as np

from . import ral26_core as rc

VARIANTS = {
    #               aoi    relax  link   battery
    "D0R":         (True,  False, False, False),     # reference: NO safety layer (nominal, actuator-clipped)
    "D24R_STATIC": (False, False, False, False),
    "D24R_AOI":    (True,  False, False, False),
    "D24R":        (True,  False, False, False),
    "D26_NOAOI":   (False, True,  True,  True),
    "D26_NOBATT":  (True,  True,  True,  False),
    "D26_NOLINK":  (True,  True,  False, True),
    "D26":         (True,  True,  True,  True),
    # v2 baselines: D24R rows + emergency, honest agents IGNORE the commanded squeeze (static spacing,
    # full route speed); _BATT adds the same energy-return supervisor D26 uses (fair energy baseline)
    "D24R_NOSQ":      (True,  False, False, False),
    "D24R_NOSQ_BATT": (True,  False, False, True),
    "D26_FULL":    (True,  True,  True,  True),
}


@dataclass
class Decision:
    u: np.ndarray
    status: str
    mode: str
    gamma: float
    nominal_unsafe: bool
    certified_horizon: float
    min_row_residual: float
    worst_age: float
    n_rows_agents: int
    n_excluded: int
    failure_reason: str
    relax: float
    refresh: bool
    solve_ms: float
    assumptions_valid: bool
    extra: dict = field(default_factory=dict)


class AgentPolicy:
    def __init__(self, variant: str, bounds: rc.Bounds, static_age_s: float = 1.0, nominal_age_s: float = 0.45,
                 gamma_warn: float = 0.5, gamma_refresh: float = 0.75, relax_up: float = 1.0, relax_down: float = 0.25,
                 horizons=(0.2, 0.4, 0.6, 1.0), planar: bool = True):
        v = variant.upper()
        if v not in VARIANTS:
            raise ValueError(f"unknown RAL26 variant {variant!r}")
        self.variant = v
        self.aoi, self.relax_on, self.link_on, self.batt_on = VARIANTS[v]
        self.B = bounds
        self.static_age = static_age_s if v.startswith("D24R") else nominal_age_s
        self.gamma_warn, self.gamma_refresh = gamma_warn, gamma_refresh
        self.relax_up, self.relax_down = relax_up, relax_down
        self.horizons = horizons
        self.planar = planar                 # u_z := 0 (PX4 holds altitude); vertical error lives in W
        self.relax = 0.0
        self.u_prev = np.zeros(3)
        self.mode = "MISSION"
        self.transitions: list = []
        self._t_last = None

    # --------------------------------------------------------------------------------------------
    def _set_mode(self, t, mode, why):
        if mode != self.mode:
            self.transitions.append({"t": t, "from": self.mode, "to": mode, "why": why})
            self.mode = mode

    def envelopes(self, t, p_own, v_own, packets):
        B = self.B
        envs, valid = [], True
        ep, ev = B.ego_err_p + B.sender_err_p, B.ego_err_v + B.sender_err_v
        for pkt in packets.values():
            if self.aoi:
                e = rc.build_envelope(pkt, t, p_own, v_own, ep, ev)
            else:
                e = rc.build_envelope(pkt, t, p_own, v_own, ep, ev, fixed_age=self.static_age)
                true_age = max(0.0, t - pkt.t_rx) + pkt.max_transit
                if true_age > self.static_age + 1e-9:          # fixed-age premise violated
                    valid = False
            if not e.valid:
                valid = False
            envs.append(e)
        return envs, valid

    def certified_horizon(self, envs, u):
        """Largest tested horizon whose rows the command satisfies (diagnostic only)."""
        best = 0.0
        for h in self.horizons:
            Bh = rc.Bounds(**{**self.B.__dict__, "h": h})
            A, b, _, _ = self._rows(envs, Bh)
            ok, _, _ = rc.recheck(u, A, b, self.B.U, self._up(), self._dmax())
            if not ok:
                break
            best = h
        return best

    def _up(self):
        return self.u_prev if math.isfinite(self.B.slew) else None

    def _dmax(self):
        return self.B.slew if math.isfinite(self.B.slew) else None

    def slew_limit(self, u):
        if not math.isfinite(self.B.slew):
            return u
        du = u - self.u_prev
        nd = float(np.linalg.norm(du))
        return u if nd <= self.B.slew else self.u_prev + du * (self.B.slew / nd)

    def _rows(self, envs, B):
        A, b, used, n_excl = rc.rows_for(envs, B)
        if self.planar and A.shape[0]:
            A = A.copy()
            A[:, 2] = 0.0
        return A, b, used, n_excl

    # --------------------------------------------------------------------------------------------
    def step(self, t, p_own, v_own, packets: dict, u_nom, energy: dict | None = None,
             tracking_valid: bool = True) -> Decision:
        t0 = time.perf_counter()
        B = self.B
        dt = 0.05 if self._t_last is None else max(1e-3, t - self._t_last)
        self._t_last = t
        u_nom = np.array(u_nom, float)
        if self.planar:
            u_nom[2] = 0.0
        nn = float(np.linalg.norm(u_nom))
        if nn > B.U:
            u_nom = u_nom * (B.U / nn)

        if self.variant == "D0R":
            u_nom = self.slew_limit(u_nom)
            self.u_prev = u_nom.copy()
            return Decision(u=u_nom, status="NO_FILTER", mode=self.mode, gamma=math.nan, nominal_unsafe=False,
                            certified_horizon=0.0, min_row_residual=math.nan, worst_age=0.0, n_rows_agents=0,
                            n_excluded=0, failure_reason="", relax=0.0, refresh=False,
                            solve_ms=1e3 * (time.perf_counter() - t0), assumptions_valid=True, extra={})
        envs, assumptions_ok = self.envelopes(t, p_own, v_own, packets)
        assumptions_ok = assumptions_ok and tracking_valid and B.tracking_valid
        worst_age = max((e.age for e in envs), default=0.0)
        A, b, used, n_excl = self._rows(envs, B)

        up, dmax = self._up(), self._dmax()
        ok_nom, _, _ = rc.recheck(u_nom, A, b, B.U)
        u, cert, res, why = rc.solve_hard_safety(u_nom, A, b, B.U, up, dmax)
        gamma, u_star, g_valid = rc.authority_reserve_m(A, b, B.U, up, dmax)
        if not cert:
            # documented emergency policy (identical for D24R and D26): per-row L1-slack soft QP;
            # u* (max reserve) only if that solve fails its validation
            # rows rebuilt on the BEST ESTIMATE (beta = 0, A_j = 0; age-propagated centres, ego errors and W
            # kept), so near neighbours dominate instead of stale worst-case envelopes
            est = {}
            for j, q in packets.items():
                est[j] = rc.NeighborPacket(q.sender, q.p_msg, q.v_msg, q.t_rx, q.max_transit, 0.0, 0.0, 0.0)
            envs_e, _ = self.envelopes(t, p_own, v_own, est)
            Ae, be, _, _ = self._rows(envs_e, B)
            u_lv = rc.least_violation_command(u_nom, Ae, be, B.U, None, up, dmax)
            u = u_star if u_lv is None else u_lv
            res = float(np.min(A @ u - b)) if A.shape[0] else math.inf
        if self.planar:
            u = np.array(u, float); u[2] = 0.0
        self.u_prev = np.array(u, float)
        status = rc.CERTIFIED if cert else rc.UNCERTIFIED
        if not assumptions_ok:
            status = rc.INVALID

        # ---- D26 supervisor (lexicographic: safety rows above, then mission/communication/energy)
        refresh = False
        if self.relax_on:
            if gamma < self.gamma_warn or not cert:
                self.relax = min(1.0, self.relax + self.relax_up * dt)
            else:
                self.relax = max(0.0, self.relax - self.relax_down * dt)
        if self.link_on and gamma < self.gamma_refresh and used:
            refresh = True
        e_margin = math.nan
        if energy is not None and self.batt_on:
            e_margin = energy.get("margin_wh", math.nan)
            if energy.get("mode") == rc.RETURN_REQUIRED and self.mode in ("MISSION", "EMERGENCY"):
                self._set_mode(t, "RETURN_REQUIRED", f"energy margin {e_margin:.3f} Wh < 0")
        if not cert and self.mode == "MISSION":
            self._set_mode(t, "EMERGENCY", why or "rows infeasible")
        elif cert and self.mode == "EMERGENCY":
            self._set_mode(t, "MISSION", "certificate regained")

        ch = self.certified_horizon(envs, u) if cert else 0.0
        return Decision(u=np.asarray(u, float), status=status, mode=self.mode, gamma=float(gamma),
                        nominal_unsafe=not ok_nom, certified_horizon=ch,
                        min_row_residual=float(res), worst_age=float(worst_age), n_rows_agents=len(used),
                        n_excluded=n_excl, failure_reason=why if not cert else "", relax=self.relax,
                        refresh=refresh, solve_ms=1e3 * (time.perf_counter() - t0),
                        assumptions_valid=bool(assumptions_ok),
                        extra={"gamma_validated": bool(g_valid), "energy_margin_wh": e_margin,
                               "rows_with": used})
