#!/usr/bin/env python3
"""RAL26 v2 confirmatory analysis (experiments/ral26/PREREG_v2.md).  Run inside the image after
ral26_audit_v2.py:

    python3 scripts/analysis/ral26_v2_report.py results/ral26/v2_main [--contrasts D26:D24R_NOSQ,D26:D24R,...]

Primary endpoint: per-episode minimum honest-attacker truth separation (50 Hz), paired by seed
(identical randomised scenario across defences).  Wilcoxon signed-rank (two-sided) + bootstrap CI of the
mean paired difference; contact rates at 1.5 / 1.0 / 0.8 m with Wilson CIs and exact McNemar; physical
crash = any vehicle tilt > 60 deg in the mission window.  Writes <root>/v2_episodes.csv, v2_cells.csv,
v2_paired.csv and v2_report.md.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ral26_report import episode_row, md, wilson  # noqa: E402

THR = (1.5, 1.0, 0.8)


def load(root: Path, rtf_min: float):
    audit = {}
    f = root / "audit_v2.json"
    if f.exists():
        audit = {r["name"]: r for r in json.loads(f.read_text())}
    rows = []
    for rd in sorted(p for p in root.iterdir() if p.is_dir() and not p.name.startswith("_")):
        r = episode_row(rd, rtf_min)
        try:
            ev = json.loads((rd / "eval" / "summary.json").read_text())
            if not ev.get("isolation_ok", False):
                r["censored"] = r.get("censored") or "isolation_fail"
            r["max_tilt_deg"] = ev.get("max_tilt_deg")
        except Exception:
            pass
        try:
            cfg = json.loads((rd / "resolved_config.json").read_text())
            draw = cfg.get("ral26", {}).get("scenario_draw", {})
            r.update({f"draw_{k}": v for k, v in draw.items() if not isinstance(v, list)})
        except Exception:
            pass
        tr = []
        for s in (rd / "agents").glob("agent_*_summary.json"):
            t = json.loads(s.read_text()).get("transit_s")
            if t:
                tr.append(t)
        if tr:
            r["transit_p99_max"] = max(t["p99"] for t in tr)
            r["transit_max"] = max(t["max"] for t in tr)
            r["transit_frac_over"] = max(t["frac_over_T_net_max"] for t in tr)
        a = audit.get(rd.name)
        if a and "error" not in a:
            ct = a.get("cert_ticks", 0)
            r.update({"cert_ticks": ct, "prem_all_frac": a["prem_all"] / ct if ct else np.nan,
                      "prem_rep_frac": a["prem_rep"] / ct if ct else np.nan,
                      "prem_acc_frac": a["prem_acc"] / ct if ct else np.nan,
                      "cert_viol": a.get("viol", 0), "cert_viol_prem_ok": a.get("viol_prem_ok", 0),
                      "crash": a.get("t_crash") is not None and bool(a.get("crash_vehicles")),
                      "rep_err_p_att": a.get("rep_err_p_max_attacker"), "acc_max_att": a.get("acc_max_attacker"),
                      "rep_err_v_honest": a.get("rep_err_v_max_honest")})
        else:
            r["crash"] = bool((r.get("max_tilt_deg") or 0) > 60.0)
        rows.append(r)
    df = pd.DataFrame(rows)
    for t in THR:
        df[f"ha<{t}"] = df.min_sep_ha.astype(float) < t
        df[f"hh<{t}"] = df.min_sep_hh.astype(float) < t
    return df


def cells(df):
    out = []
    for (cell, d), g in df.groupby(["cell", "defense"]):
        n = len(g)
        r = {"cell": cell, "defense": d, "n": n}
        if g.min_sep_ha.notna().any():
            x = g.min_sep_ha.astype(float)
            r["sep_ha_med"] = x.median()
            r["sep_ha_iqr"] = f"[{x.quantile(.25):.2f},{x.quantile(.75):.2f}]"
            r["sep_ha_min"] = x.min()
            for t in THR:
                k = int(g[f"ha<{t}"].sum())
                lo, hi = wilson(k, n)
                r[f"ha<{t}"] = f"{k}/{n} [{lo:.2f},{hi:.2f}]"
        r["crash"] = f"{int(g.crash.fillna(False).astype(bool).sum())}/{n}"
        r["sep_hh_min"] = g.min_sep_hh.astype(float).min()
        r["hh<1.5"] = int(g["hh<1.5"].sum())
        for c in ("frac_certified", "frac_uncertified", "frac_invalid", "prem_all_frac", "prem_rep_frac", "prem_acc_frac",
                  "sched_rmse", "relax_mean", "bytes_per_s_honest", "max_goal_progress_m", "transit_p99_max",
                  "transit_frac_over", "solve_ms_p99", "deadline_miss", "rep_err_p_att", "acc_max_att",
                  "rep_err_v_honest", "safe_return", "ob_completed", "returned_n", "E_end_min_wh_est",
                  "energy_depleted_n", "safe_mission"):
            if c in g and g[c].notna().any():
                r[c] = float(pd.to_numeric(g[c], errors="coerce").mean())
        for c in ("cert_viol", "cert_viol_prem_ok", "cert_ticks"):
            if c in g:
                r[c] = int(g[c].fillna(0).sum())
        out.append(r)
    return pd.DataFrame(out)


def mcnemar_exact(b, c):
    n = b + c
    if n == 0:
        return 1.0
    return float(min(1.0, 2 * stats.binom.cdf(min(b, c), n, 0.5)))


def paired(df, contrasts, B=10000, seed=0):
    rng = np.random.default_rng(seed)
    rows = []
    for cell, g in df.groupby("cell"):
        for a, b in contrasts:
            A = g[g.defense == a].set_index("seed")
            Bd = g[g.defense == b].set_index("seed")
            com = A.index.intersection(Bd.index)
            if len(com) < 3:
                continue
            r = {"cell": cell, "contrast": f"{a} - {b}", "n_pairs": len(com)}
            for m in ("min_sep_ha", "min_sep_hh", "sched_rmse", "bytes_per_s_honest", "max_goal_progress_m",
                      "E_end_min_wh_est"):
                if m not in A or m not in Bd:
                    continue
                x = pd.to_numeric(A.loc[com, m], errors="coerce").to_numpy(float)
                y = pd.to_numeric(Bd.loc[com, m], errors="coerce").to_numpy(float)
                ok = np.isfinite(x) & np.isfinite(y)
                if ok.sum() < 3:
                    continue
                dlt = x[ok] - y[ok]
                bs = rng.choice(dlt, (B, len(dlt))).mean(axis=1)
                r[f"{m}_mean_diff"] = float(dlt.mean())
                r[f"{m}_ci"] = f"[{np.quantile(bs, .025):+.3f},{np.quantile(bs, .975):+.3f}]"
                r[f"{m}_median_diff"] = float(np.median(dlt))
                if m == "min_sep_ha":
                    r["wins_a"] = int((dlt > 0).sum())
                    r["wins_b"] = int((dlt < 0).sum())
                    r["wilcoxon_p"] = float(stats.wilcoxon(dlt).pvalue) if np.any(dlt != 0) else 1.0
            for t in THR:
                c = f"ha<{t}"
                if c in A and A[c].notna().any():
                    xa, xb = A.loc[com, c].astype(bool), Bd.loc[com, c].astype(bool)
                    bb, cc = int((xa & ~xb).sum()), int((~xa & xb).sum())
                    r[f"{c}_a/b"] = f"{int(xa.sum())}/{int(xb.sum())}"
                    r[f"{c}_mcnemar_p"] = mcnemar_exact(bb, cc)
            xa, xb = A.loc[com, "crash"].fillna(False).astype(bool), Bd.loc[com, "crash"].fillna(False).astype(bool)
            r["crash_a/b"] = f"{int(xa.sum())}/{int(xb.sum())}"
            r["crash_mcnemar_p"] = mcnemar_exact(int((xa & ~xb).sum()), int((~xa & xb).sum()))
            rows.append(r)
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("--rtf-min", type=float, default=0.95)
    ap.add_argument("--contrasts", default="D26:D24R_NOSQ,D26:D24R,D24R_NOSQ:D24R,D24R:D0R,D26:D0R")
    ap.add_argument("--keep-crash-censored", action="store_true",
                    help="declared deviation (DEVIATIONS_v2.md): analyse gcs_code_3 episodes whose mission window "
                         "completed and that crashed; the GCS exits 3 when a flipped vehicle cannot finish landing")
    a = ap.parse_args()
    root = Path(a.root)
    df = load(root, a.rtf_min)
    sfx = ""
    if a.keep_crash_censored:
        sfx = "_keepcrash"
        keep = (df.censored == "gcs_code_3") & df.crash.fillna(False).astype(bool) & df.min_sep_ha.notna()
        df.loc[keep, "censored"] = None
    df.to_csv(root / f"v2_episodes{sfx}.csv", index=False)
    cens = df[df.censored.notna()]
    ok = df[df.censored.isna()].copy()
    tab = cells(ok)
    tab.to_csv(root / f"v2_cells{sfx}.csv", index=False)
    con = [tuple(c.split(":")) for c in a.contrasts.split(",")]
    pr = paired(ok, con)
    pr.to_csv(root / f"v2_paired{sfx}.csv", index=False)
    pd.set_option("display.width", 300)
    with open(root / f"v2_report{sfx}.md", "w") as fh:
        fh.write(f"# {root.name} (v2, pre-registered: experiments/ral26/PREREG_v2.md)\n\n")
        if sfx:
            fh.write("**Deviation from the pre-registered validity rule** (see DEVIATIONS_v2.md): crashed episodes with "
                     "GCS exit code 3 are analysed.\n\n")
        fh.write(f"episodes {len(df)}, analysed {len(ok)}, censored {len(cens)}\n\n")
        if len(cens):
            fh.write("## Censored\n\n" + md(cens[["name", "censored", "rtf_mean"]]) + "\n\n")
        fh.write("## Cells\n\n" + md(tab) + "\n\n")
        if len(pr):
            fh.write("## Paired contrasts (same seed = same randomised scenario)\n\n" + md(pr) + "\n")
    print((root / f"v2_report{sfx}.md").read_text())


if __name__ == "__main__":
    main()
