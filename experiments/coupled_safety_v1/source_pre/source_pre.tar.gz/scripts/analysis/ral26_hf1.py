#!/usr/bin/env python3
"""HF1 analysis: PX4 offboard authority / tracking-residual identification from PX4 SITL + Gazebo flights.

For every vehicle-tick in offboard (nav_state 14):
    e = a - [u_x, u_y, 0]      (3-D; vertical deviation of the altitude hold is part of e)
where a is PX4's own acceleration estimate (vehicle_local_position ax/ay/az, same clock as u).  The PX4
estimate is cross-checked against Gazebo ground truth (positions differentiated twice after aligning
the clocks by velocity cross-correlation).  W_train = max ||e|| over TRAIN flights; coverage = fraction
of HOLDOUT ticks / held intervals with ||e|| <= W_train.  Step responses: delay to 50 %, rise to 90 %,
overshoot and 10 % settling of the projection of a on the commanded direction.

    python3 scripts/analysis/ral26_hf1.py results/ral26/hf1   (inside the image: needs pandas)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

OFFBOARD = 14


def load_flight(rd: Path):
    cfg = json.loads((rd / "resolved_config.json").read_text())
    rows = []
    for f in sorted((rd / "agents").glob("hf1_*.csv*")):
        uid = int(f.name.split("_")[1].split(".")[0])
        d = pd.read_csv(f)
        d["uid"] = uid
        rows.append(d)
    if not rows:
        return None, cfg
    return pd.concat(rows, ignore_index=True), cfg


def close_cutoff(rd: Path, n: int, thr=2.0):
    """Mission time at which each vehicle first comes within thr metres of another (Gazebo truth);
    identification data after that instant is discarded (possible contact)."""
    tf = rd / "eval" / "truth.csv"
    summ = json.loads((rd / "eval" / "summary.json").read_text())
    if not tf.exists() or summ.get("t_mission_start_sim") is None:
        return {i: -np.inf for i in range(n)}
    T = pd.read_csv(tf)
    t = T.t_sim.to_numpy() - summ["t_mission_start_sim"]
    P = np.stack([T[[f"x{i}", f"y{i}", f"z{i}"]].to_numpy() for i in range(n)], axis=1)
    out = {}
    for i in range(n):
        d = np.min([np.linalg.norm(P[:, i] - P[:, j], axis=1) for j in range(n) if j != i], axis=0)
        idx = np.flatnonzero((d < thr) & (t > 0))
        out[i] = float(t[idx[0]]) if idx.size else np.inf
    return out


def truth_check(rd: Path, d: pd.DataFrame, geo):
    """EKF vs Gazebo truth acceleration error (per vehicle), after clock alignment."""
    tf = rd / "eval" / "truth.csv"
    summ = json.loads((rd / "eval" / "summary.json").read_text())
    if not tf.exists() or summ.get("t_mission_start_sim") is None:
        return {}
    T = pd.read_csv(tf)
    t0 = summ["t_mission_start_sim"]
    out = {}
    for uid, g in d.groupby("uid"):
        ts = T["t_sim"].to_numpy() - t0
        x = T[f"x{uid}"].to_numpy(); y = T[f"y{uid}"].to_numpy()
        if len(ts) < 50:
            continue
        # resample truth on a 50 Hz grid, smooth, differentiate
        grid = np.arange(max(ts[0], g.t.min()), min(ts[-1], g.t.max()), 0.02)
        if len(grid) < 100:
            continue
        xi = np.interp(grid, ts, x); yi = np.interp(grid, ts, y)
        k = np.ones(5) / 5

        def sm(z):                                         # edge-padded moving average (no zero padding)
            return np.convolve(np.pad(z, 2, mode="edge"), k, "valid")
        vx = np.gradient(sm(xi), grid); vy = np.gradient(sm(yi), grid)
        ax = np.gradient(sm(vx), grid); ay = np.gradient(sm(vy), grid)
        evx = np.interp(grid, g.t, g.vx)
        best, lag = -1, 0.0
        for L in np.arange(-0.5, 0.5, 0.02):              # clock alignment by velocity xcorr
            c = np.corrcoef(np.interp(grid + L, grid, vx), evx)[0, 1]
            if c > best:
                best, lag = c, L
        eax = np.interp(grid, g.t, g.ax); eay = np.interp(grid, g.t, g.ay)
        tax = np.interp(grid + lag, grid, ax); tay = np.interp(grid + lag, grid, ay)
        sl = slice(10, -10)
        err = np.hypot(eax - tax, eay - tay)[sl]
        # truth-based tracking residual on the command clock: e_T = a_truth - u (xy) + |az| bound from PX4
        ux = np.interp(grid, g.t, g.ux); uy = np.interp(grid, g.t, g.uy)
        valid = np.interp(grid, g.t, g.t.diff().fillna(0).lt(0.1).astype(float).to_numpy()) > 0.99
        eT = np.hypot(tax - ux, tay - uy)[sl][valid[sl]]
        out[int(uid)] = {"lag_s": float(lag), "vel_corr": float(best), "acc_err_p50": float(np.median(err)),
                         "acc_err_p99": float(np.quantile(err, 0.99)), "eT": eT}
    return out


def step_metrics(g: pd.DataFrame):
    res = []
    for seg, s in g.groupby("seg"):
        if s.kind.iloc[0] not in ("step", "reversal") or len(s) < 20:
            continue
        u = s[["ux", "uy"]].to_numpy()
        um = np.linalg.norm(u[-1])
        if um < 0.4:
            continue
        dirn = u[-1] / um
        a = s[["ax", "ay"]].to_numpy() @ dirn
        a0 = a[0]
        t = s.t.to_numpy() - s.t.iloc[0]
        span = um - a0
        if abs(span) < 0.3:
            continue
        frac = (a - a0) / span

        def first(th):
            idx = np.flatnonzero(frac >= th)
            return float(t[idx[0]]) if idx.size else np.nan
        settle = np.nan
        out_band = np.flatnonzero(np.abs(a - um) > 0.1 * um)
        if out_band.size and out_band[-1] + 1 < len(t):
            settle = float(t[out_band[-1] + 1])
        elif not out_band.size:
            settle = 0.0
        res.append({"seg": seg, "kind": s.kind.iloc[0], "u": float(um), "delay50": first(0.5), "rise90": first(0.9),
                    "overshoot": float(max(0.0, (a.max() - um) / um)), "settle10": settle,
                    "ss_err": float(np.mean(np.abs(a[-10:] - um)))})
    return res


def main():
    root = Path(sys.argv[1])
    flights = []
    for rd in sorted(p for p in root.iterdir() if p.is_dir()):
        d, cfg = load_flight(rd)
        if d is None:
            continue
        H = cfg.get("hf1", {})
        cut = close_cutoff(rd, int(cfg["swarm"]["num_uavs"]))
        d = d[(d.nav == OFFBOARD) & (d.t < d.uid.map(cut) - 0.5)].copy()
        d["mode"], d["jerk"], d["flight"] = H.get("mode"), float(H.get("jerk", 0)), rd.name
        d["split"] = "train" if int(cfg["experiment"]["seed"]) % 2 == 0 else "holdout"
        d["e"] = np.sqrt((d.ax - d.ux) ** 2 + (d.ay - d.uy) ** 2 + d.az ** 2)
        d["e_xy"] = np.hypot(d.ax - d.ux, d.ay - d.uy)
        d["unorm"] = np.hypot(d.ux, d.uy)
        d["anorm"] = np.hypot(d.ax, d.ay)
        flights.append((rd, d, truth_check(rd, d, None)))
    D = pd.concat([f[1] for f in flights], ignore_index=True)
    report = {"flights": [f[0].name for f in flights], "ticks": int(len(D)), "classes": {}, "truth_check": {}}
    eT = {}
    for rd, d, tc in flights:
        key = f"{d['mode'].iloc[0]}_jerk{d['jerk'].iloc[0]:g}"
        for uid, v in tc.items():
            eT.setdefault(key, {"train": [], "holdout": []})[d["split"].iloc[0]].append(v.pop("eT"))
        report["truth_check"][rd.name] = tc
    report["truth_residual"] = {}
    for key, v in eT.items():
        tr = np.concatenate(v["train"]) if v["train"] else np.zeros(0)
        ho = np.concatenate(v["holdout"]) if v["holdout"] else np.zeros(0)
        W = float(tr.max()) if tr.size else np.nan
        report["truth_residual"][key] = {"W_truth_xy_train_max": W, "W_truth_xy_train_p99": float(np.quantile(tr, 0.99)),
                                         "W_truth_xy_train_p999": float(np.quantile(tr, 0.999)),
                                         "holdout_max": float(ho.max()), "holdout_cov_trainmax": float(np.mean(ho <= W)),
                                         **{f"holdout_cov_W{w}": float(np.mean(ho <= w)) for w in (2.5, 3.0, 3.5)},
                                         **{f"train_cov_W{w}": float(np.mean(tr <= w)) for w in (2.5, 3.0, 3.5)},
                                         "n_train": int(tr.size), "n_holdout": int(ho.size)}
    for (mode, jerk), g in D.groupby(["mode", "jerk"]):
        key = f"{mode}_jerk{jerk:g}"
        tr, ho = g[g.split == "train"], g[g.split == "holdout"]
        W_tr = float(tr.e.max()) if len(tr) else np.nan
        W99 = float(tr.e.quantile(0.99)) if len(tr) else np.nan
        # per held interval coverage (seg id within flight/uid)
        hi = ho.groupby(["flight", "uid", "seg"]).e.max()
        steps = []
        for _, gg in g.groupby(["flight", "uid"]):
            steps += step_metrics(gg)
        S = pd.DataFrame(steps)
        by_mag = {}
        for lo, hi_ in ((0, 3.01), (3.01, 5.51)):
            sel = tr[(tr.unorm > lo) & (tr.unorm <= hi_)]
            by_mag[f"|u| in ({lo},{hi_}]"] = {"W_max": float(sel.e.max()) if len(sel) else None,
                                              "W_p99": float(sel.e.quantile(0.99)) if len(sel) else None, "ticks": int(len(sel))}
        report["classes"][key] = {
            "ticks_train": int(len(tr)), "ticks_holdout": int(len(ho)),
            "W_train_max": W_tr, "W_train_p99": W99, "W_train_p999": float(tr.e.quantile(0.999)) if len(tr) else None,
            "holdout_tick_coverage_Wmax": float(np.mean(ho.e <= W_tr)) if len(ho) else None,
            "holdout_interval_coverage_Wmax": float(np.mean(hi <= W_tr)) if len(hi) else None,
            "holdout_max_e": float(ho.e.max()) if len(ho) else None,
            "e_xy_p50": float(g.e_xy.median()), "e_xy_p99": float(g.e_xy.quantile(0.99)),
            "az_abs_p99": float(g.az.abs().quantile(0.99)),
            "peak_accel_xy": float(g.anorm.max()),
            "by_command_magnitude_train": by_mag,
            "n_step_responses": int(len(S)),
            "delay50_med_s": float(S.delay50.median()) if len(S) else None,
            "delay50_p90_s": float(S.delay50.quantile(0.9)) if len(S) else None,
            "rise90_med_s": float(S.rise90.median()) if len(S) else None,
            "overshoot_med": float(S.overshoot.median()) if len(S) else None,
            "overshoot_p90": float(S.overshoot.quantile(0.9)) if len(S) else None,
            "settle10_med_s": float(S.settle10.median()) if len(S) else None,
            "ss_err_med": float(S.ss_err.median()) if len(S) else None,
            "steps_by_u": S.groupby(S.u.round(1)).size().to_dict() if len(S) else {},
            "loop_dt_p99": float(g.t.groupby([g.flight, g.uid]).diff().quantile(0.99)),
        }
    out = root / "hf1_report.json"
    out.write_text(json.dumps(report, indent=1, default=float))
    print(json.dumps(report["classes"], indent=1, default=float))
    print(json.dumps(report["truth_residual"], indent=1))


if __name__ == "__main__":
    main()
