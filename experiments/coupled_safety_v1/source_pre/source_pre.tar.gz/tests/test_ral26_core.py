"""Tests for the RAL26 core mathematics, the per-agent policies and the FANET channel model.

These test CONTROLLER mathematics only; no test here produces a flight result.
"""
import math

import numpy as np

from swarmsec import ral26_core as rc
from swarmsec.fanet import Fanet, FanetConfig, outage_schedule
from swarmsec.ral26_policy import AgentPolicy


def _pkt(p, v, t_rx=0.0, T=0.1, bp=0.5, bv=0.2, A=3.0, sender=1):
    return rc.NeighborPacket(sender, np.asarray(p, float), np.asarray(v, float), t_rx, T, bp, bv, A)


def test_envelope_age_formula():
    pk = _pkt([5, 0, 0], [1, 0, 0], t_rx=1.0, T=0.1, bp=0.5, bv=0.2, A=3.0)
    e = rc.build_envelope(pk, 1.4, [0, 0, 0], [0, 0, 0], 0.1, 0.05)
    a = 0.4 + 0.1
    assert abs(e.age - a) < 1e-12
    assert np.allclose(e.r_hat, -(np.array([5, 0, 0]) + a * np.array([1, 0, 0])))
    assert abs(e.B_p - (0.5 + a * 0.2 + 0.5 * 3.0 * a * a + 0.1)) < 1e-12
    assert abs(e.B_v - (0.2 + 3.0 * a + 0.05)) < 1e-12
    # receive time in the future of 'now' is clamped at zero elapsed
    e2 = rc.build_envelope(pk, 0.5, [0, 0, 0], [0, 0, 0], 0, 0)
    assert abs(e2.age - 0.1) < 1e-12


def test_envelope_invalid_when_transit_unbounded():
    e = rc.build_envelope(_pkt([5, 0, 0], [0, 0, 0], T=math.inf), 0.0, [0, 0, 0], [0, 0, 0], 0, 0)
    assert not e.valid


def test_rows_k0_is_u_independent_and_infeasible_when_too_close():
    e = rc.build_envelope(_pkt([1.0, 0, 0], [0, 0, 0]), 0.0, [0, 0, 0], [0, 0, 0], 0, 0)
    A, b, _ = rc.certificate_rows(e, 0.6, 6, 3.0, 1.0, 1.5)
    assert np.allclose(A[0], 0.0) and b[0] > 0
    u, cert, _, why = rc.solve_hard_safety(np.zeros(3), A, b, 3.0)
    assert u is None and not cert and why == "k0_infeasible"
    g, _, _ = rc.authority_reserve_m(A, b, 3.0)
    assert g < 0


def _simulate_worst(e, u, h, W, rng, dt=1e-3):
    """Random admissible realisation: initial state inside the balls, bounded neighbour/ego residual
    accelerations (piecewise constant, adversarially biased toward closing)."""
    r = e.r_hat + rng.normal(size=3) * 0
    d = rng.normal(size=3); r = e.r_hat + e.B_p * rng.random() * d / np.linalg.norm(d)
    d = rng.normal(size=3); v = e.v_hat + e.B_v * rng.random() * d / np.linalg.norm(d)
    dmin = np.linalg.norm(r)
    t = 0.0
    while t < h:
        toward = -r / max(np.linalg.norm(r), 1e-9)
        aj = -e.A_j * toward if rng.random() < 0.8 else e.A_j * rng.normal(size=3) / np.sqrt(3) * 0.5
        if np.linalg.norm(aj) > e.A_j:
            aj *= e.A_j / np.linalg.norm(aj)
        ei = W * toward if rng.random() < 0.8 else 0.0 * toward
        acc = u - aj + ei
        v = v + acc * dt
        r = r + v * dt
        t += dt
        dmin = min(dmin, np.linalg.norm(r))
    return dmin


def test_certificate_inter_sample_soundness_random():
    """Fine-time-step check (1 ms) that certified commands keep ||r(tau)|| >= d_safe on [0,h] for
    random admissible realisations -- the priority-4 inter-sample question, at the math level."""
    rng = np.random.default_rng(3)
    checked = 0
    for _ in range(150):
        p = rng.normal(size=3) * 3.0
        p[2] *= 0.2
        e = rc.build_envelope(_pkt(p, rng.normal(size=3), t_rx=0, T=0.1, bp=0.3, bv=0.2, A=2.0),
                              rng.random() * 0.3, [0, 0, 0], rng.normal(size=3) * 0.5, 0.05, 0.05)
        A, b, _ = rc.certificate_rows(e, 0.6, 6, 3.0, 0.8, 1.0)
        u, cert, res, _ = rc.solve_hard_safety(rng.normal(size=3), A, b, 3.0)
        if not cert:
            continue
        assert res >= -rc.ROW_TOL
        assert rc.interval_lower_bound(e, u, 0.6, 0.8, samples=2000) >= 1.0 - 1e-6
        for _ in range(5):
            assert _simulate_worst(e, u, 0.6, 0.8, rng) >= 1.0 - 1e-3
        checked += 1
    assert checked >= 20, checked


def test_solver_hard_rows_no_slack_and_norm():
    e = rc.build_envelope(_pkt([4.0, 0, 0], [-1.0, 0, 0]), 0.0, [0, 0, 0], [0, 0, 0], 0.05, 0.05)
    A, b, _ = rc.certificate_rows(e, 0.6, 6, 3.0, 0.5, 1.5)
    u_nom = np.array([3.0, 0, 0])               # pushes INTO the neighbour
    u, cert, res, _ = rc.solve_hard_safety(u_nom, A, b, 3.0)
    assert cert and np.linalg.norm(u) <= 3.0 + 1e-7 and np.min(A @ u - b) >= -1e-6
    ok, _, _ = rc.recheck(u_nom, A, b, 3.0)
    assert not ok


def test_gamma_sign_matches_feasibility():
    rng = np.random.default_rng(0)
    agree = 0
    for _ in range(60):
        p = rng.normal(size=3) * 2.5
        e = rc.build_envelope(_pkt(p, rng.normal(size=3)), 0.0, [0, 0, 0], [0, 0, 0], 0.05, 0.05)
        A, b, _ = rc.certificate_rows(e, 0.6, 6, 3.0, 0.5, 1.5)
        g, ustar, _ = rc.authority_reserve_m(A, b, 3.0)
        _, cert, _, _ = rc.solve_hard_safety(np.zeros(3), A, b, 3.0)
        if abs(g) < 1e-4:
            continue
        assert (g >= 0) == cert, (g, cert)
        agree += 1
    assert agree > 30


def test_exclusion_is_sound():
    rng = np.random.default_rng(1)
    for _ in range(200):
        p = rng.normal(size=3) * 8
        e = rc.build_envelope(_pkt(p, rng.normal(size=3)), 0.0, [0, 0, 0], [0, 0, 0], 0.05, 0.05)
        if rc.exclusion_safe(e, 0.6, 3.0, 0.5, 1.5):
            u = rng.normal(size=3); u *= 3.0 / np.linalg.norm(u)
            assert _simulate_worst(e, u, 0.6, 0.5, rng) >= 1.5 - 1e-3


def test_energy_supervisor_and_update():
    assert abs(rc.update_energy_wh(10.0, 360.0, 10.0) - 9.0) < 1e-12
    assert rc.update_energy_wh(0.001, 360.0, 10.0) == 0.0
    s = rc.energy_supervisor(5.0, 300.0, 36.0, 1.0)
    assert abs(s["E_return_upper_wh"] - 3.0) < 1e-12 and abs(s["margin_wh"] - 1.0) < 1e-12 and s["mode"] == rc.ENERGY_OK
    assert rc.energy_supervisor(3.5, 300.0, 36.0, 1.0)["mode"] == rc.RETURN_REQUIRED
    assert rc.energy_supervisor(3.5, math.nan, 36.0, 1.0)["mode"] == rc.UNKNOWN_ENERGY
    assert rc.energy_supervisor(3.5, 300.0, 36.0, 1.0, valid=False)["mode"] == rc.UNKNOWN_ENERGY


def test_range_lower_bound():
    assert abs(rc.minimal_range_lower_bound(5.0, 0.2, 2.0, 0.1, 0.5) - (5.0 - 0.2 - 1.2)) < 1e-12
    assert rc.minimal_range_lower_bound(0.5, 0.2, 2.0, 0.1, 0.5) == 0.0


def test_combined_resource_state():
    s = rc.combined_resource_state(0.1, 0.5, True, True)
    assert s["eligible"]
    assert not rc.combined_resource_state(-0.1, 0.5, True, True)["eligible"]
    assert not rc.combined_resource_state(0.1, -0.5, True, True)["eligible"]
    assert not rc.combined_resource_state(0.1, 0.5, False, True)["eligible"]


def test_policy_variants_share_rows_and_flag_assumptions():
    B = rc.Bounds(U=3.0, W=0.5, beta_p=0.5, beta_v=0.2, T_net_max=0.1, d_safe=1.5, h=0.6, M=6)
    pk = {1: _pkt([4.0, 0, 0], [-0.5, 0, 0], t_rx=0.0, T=0.1, bp=0.5, bv=0.2, A=3.0)}
    u_nom = np.array([2.0, 0, 0])
    d_static = AgentPolicy("D24R_STATIC", B, static_age_s=1.0).step(0.2, np.zeros(3), np.zeros(3), pk, u_nom)
    d_aoi = AgentPolicy("D24R_AOI", B).step(0.2, np.zeros(3), np.zeros(3), pk, u_nom)
    d26 = AgentPolicy("D26", B).step(0.2, np.zeros(3), np.zeros(3), pk, u_nom)
    # AoI-matched D24R and D26 solve the same rows -> same command on the same inputs
    assert np.allclose(d_aoi.u, d26.u, atol=1e-5) and d_aoi.status == d26.status
    # static worst-case age is more conservative -> smaller reserve
    assert d_static.gamma <= d_aoi.gamma + 1e-9
    # fixed nominal-age variant flags INVALID_ASSUMPTIONS once the real packet age exceeds it
    p = AgentPolicy("D26_NOAOI", B, nominal_age_s=0.2)
    d = p.step(1.5, np.zeros(3), np.zeros(3), pk, u_nom)
    assert d.status == rc.INVALID and not d.assumptions_valid
    # certified commands are never marked certified when rows fail
    for dd in (d_static, d_aoi, d26):
        if dd.status == rc.CERTIFIED:
            assert dd.min_row_residual >= -rc.ROW_TOL


def test_policy_emergency_and_relaxation():
    B = rc.Bounds(U=3.0, W=0.5, beta_p=0.5, beta_v=0.2, T_net_max=0.1, d_safe=1.5, h=0.6, M=6)
    pk = {1: _pkt([1.2, 0, 0], [0, 0, 0])}
    p = AgentPolicy("D26", B)
    for k in range(10):
        d = p.step(0.05 * k, np.zeros(3), np.zeros(3), pk, np.array([1.0, 0, 0]))
    assert d.status == rc.UNCERTIFIED and d.mode == "EMERGENCY" and d.relax > 0 and d.refresh
    assert d.u[0] <= 0                     # emergency max-reserve command moves away
    p24 = AgentPolicy("D24R", B)
    d = p24.step(0.0, np.zeros(3), np.zeros(3), pk, np.array([1.0, 0, 0]))
    assert d.relax == 0.0 and not d.refresh


def test_policy_energy_return_only_with_battery_variant():
    B = rc.Bounds()
    en = rc.energy_supervisor(1.0, 300.0, 60.0, 0.5)
    assert en["mode"] == rc.RETURN_REQUIRED
    assert AgentPolicy("D26", B).step(0.0, np.zeros(3), np.zeros(3), {}, np.zeros(3), energy=en).mode == "RETURN_REQUIRED"
    assert AgentPolicy("D26_NOBATT", B).step(0.0, np.zeros(3), np.zeros(3), {}, np.zeros(3), energy=en).mode == "MISSION"
    assert AgentPolicy("D24R", B).step(0.0, np.zeros(3), np.zeros(3), {}, np.zeros(3), energy=en).mode == "MISSION"


def test_fanet_transit_bound_budget_and_partition():
    rng = np.random.default_rng(0)
    cfg = FanetConfig(delay_s=0.1, jitter_s=0.3, t_net_max=0.25, bucket_bytes_per_s=720, bucket_burst_bytes=144)
    f = Fanet(3, cfg, rng)
    pos = np.zeros((3, 3))
    sent = sum(f.send(0.0, 0, "x", pos) for _ in range(5))
    assert sent == 2 and f.stats["budget_drop"] == 3        # 144 B burst / 72 B packets
    out = f.due(10.0)
    for ta, i, j, _ in out:
        assert ta - 0.0 <= 0.25 + 1e-12
    assert f.stats["late_drop"] > 0 or len(out) == 4
    # partition cuts only cross links
    cfg2 = FanetConfig(outages=outage_schedule("partition", 4, 0.0, 5.0))
    f2 = Fanet(4, cfg2, rng)
    f2.send(1.0, 0, "x", np.zeros((4, 3)))
    rx = sorted(i for _, i, _, _ in f2.due(2.0))
    assert rx == [1]
    # hard range
    f3 = Fanet(2, FanetConfig(range_m=10.0), rng)
    f3.send(0.0, 0, "x", np.array([[0, 0, 0], [20.0, 0, 0]]))
    assert f3.due(1.0) == [] and f3.stats["range_drop"] == 1


def test_fanet_gilbert_elliott_bursts():
    rng = np.random.default_rng(5)
    f = Fanet(2, FanetConfig(ge_p_gb=0.05, ge_p_bg=0.2), rng)
    got = []
    for k in range(4000):
        n0 = f.stats["delivered"]
        f.send(k * 0.01, 0, "x", np.zeros((2, 3)))
        f.due(k * 0.01 + 1)
        got.append(f.stats["delivered"] > n0)
    loss = 1 - np.mean(got)
    assert 0.12 < loss < 0.30, loss                         # stationary bad fraction = 0.05/0.25 = 0.2
    runs = np.diff(np.flatnonzero(np.diff(np.r_[1, np.array(got, int), 1]) != 0))
    assert runs.max() >= 10                                  # bursty, not i.i.d.


def test_registry_preserves_legacy_and_adds_ral26():
    from swarmsec.defenses import build_defense, build_agent_policy, RAL26_AGENT_DEFENSES
    for legacy in ("D0", "D18N", "D24", "D25_COMM"):
        build_defense(legacy, num_agents=4, d_safe=2.5, dt=0.05, neighbor_radius=6.0)
    for name in RAL26_AGENT_DEFENSES:
        assert build_agent_policy(name, rc.Bounds()).variant == name
    try:
        build_defense("D26", num_agents=4)
        assert False, "per-agent policy must not build as a central defense"
    except ValueError as exc:
        assert "per-agent" in str(exc)


def test_slew_constraint_is_hard_and_rechecked():
    B = rc.Bounds(U=3.0, W=0.5, beta_p=0.3, beta_v=0.2, T_net_max=0.05, d_safe=1.5, h=0.4, M=8, slew=0.4)
    p = AgentPolicy("D24R", B)
    prev = np.zeros(3)
    for k in range(30):
        d = p.step(0.05 * k, np.zeros(3), np.zeros(3), {}, np.array([3.0, 0, 0]))
        assert np.linalg.norm(d.u - prev) <= 0.4 + 1e-6
        prev = d.u
    assert abs(prev[0] - 3.0) < 1e-6                 # reaches nominal after enough ticks
    # rows + slew jointly: certified commands satisfy both, verified independently
    pk = {1: _pkt([4.5, 0, 0], [-1.0, 0, 0], T=0.05, bp=0.3, bv=0.2, A=3.0)}
    p2 = AgentPolicy("D26", B)
    for k in range(10):
        d = p2.step(0.05 * k, np.zeros(3), np.zeros(3), pk, np.array([3.0, 0, 0]))
        if d.status == rc.CERTIFIED:
            assert d.min_row_residual >= -rc.ROW_TOL


def test_emergency_soft_fallback_protects_near_neighbour_despite_stale_far_row():
    B = rc.Bounds(U=3.0, W=0.5, beta_p=0.5, beta_v=0.2, T_net_max=0.1, d_safe=1.5, h=0.6, M=6)
    # near neighbour ahead (+x, 2.4 m) and a very stale neighbour behind (-x) with a huge envelope
    pk = {1: _pkt([2.0, 0, 0], [-0.5, 0, 0]), 2: _pkt([-4.0, 0, 0], [0, 0, 0], t_rx=-3.0, sender=2)}
    d = AgentPolicy("D24R", B).step(0.0, np.zeros(3), np.zeros(3), pk, np.array([2.0, 0, 0]))
    assert d.status == rc.UNCERTIFIED
    assert d.u[0] < 1.0                     # does not keep driving into the near neighbour at nominal 2.0
    assert np.linalg.norm(d.u) <= 3.0 + 1e-6


def test_energy_return_fires_from_emergency_mode():
    """Post-fix regression: RETURN_REQUIRED must override EMERGENCY (D26_NOAOI was stuck in EMERGENCY and
    never returned in the frozen HF6 runs)."""
    B = rc.Bounds(U=3.0, W=0.5, beta_p=0.5, beta_v=0.2, T_net_max=0.1, d_safe=1.5, h=0.6, M=6)
    p = AgentPolicy("D26_NOAOI", B, nominal_age_s=0.2)
    pk = {1: _pkt([1.2, 0, 0], [0, 0, 0])}
    d = p.step(0.0, np.zeros(3), np.zeros(3), pk, np.zeros(3))
    assert d.mode == "EMERGENCY"
    en = rc.energy_supervisor(1.0, 300.0, 60.0, 0.5)
    d = p.step(0.05, np.zeros(3), np.zeros(3), pk, np.zeros(3), energy=en)
    assert d.mode == "RETURN_REQUIRED"


def test_prewarm_compiles_all_buckets():
    rc.prewarm()
    assert all(k in rc._CACHE for k in (8, 16, 32, 64))


def test_sender_error_terms_enlarge_envelope_additively():
    """v2: honest senders report their own (erroneous) estimate; B_p/B_v must include that bound."""
    B0 = rc.Bounds(U=3.0, W=0.5, beta_p=0.5, beta_v=0.2, T_net_max=0.1, ego_err_p=0.1, ego_err_v=0.05)
    B1 = rc.Bounds(**{**B0.__dict__, "sender_err_p": 0.6, "sender_err_v": 0.4})
    pk = {1: _pkt([5, 0, 0], [0, 0, 0])}
    e0, _ = AgentPolicy("D24R", B0).envelopes(0.0, np.zeros(3), np.zeros(3), pk)
    e1, _ = AgentPolicy("D24R", B1).envelopes(0.0, np.zeros(3), np.zeros(3), pk)
    assert abs((e1[0].B_p - e0[0].B_p) - 0.6) < 1e-12
    assert abs((e1[0].B_v - e0[0].B_v) - 0.4) < 1e-12


def test_nosq_variants_share_d24r_rows_and_only_batt_returns():
    B = rc.Bounds(U=3.0, W=0.5, beta_p=0.5, beta_v=0.2, T_net_max=0.1, d_safe=1.5, h=0.6, M=6)
    pk = {1: _pkt([3.0, 0, 0], [-0.5, 0, 0])}
    un = np.array([1.5, 0.0, 0.0])
    ref = AgentPolicy("D24R", B).step(0.0, np.zeros(3), np.zeros(3), pk, un)
    for v in ("D24R_NOSQ", "D24R_NOSQ_BATT"):
        d = AgentPolicy(v, B).step(0.0, np.zeros(3), np.zeros(3), pk, un)
        assert np.allclose(d.u, ref.u) and d.status == ref.status and d.relax == 0.0
    en = rc.energy_supervisor(1.0, 300.0, 60.0, 0.5)
    assert AgentPolicy("D24R_NOSQ_BATT", B).step(0.0, np.zeros(3), np.zeros(3), pk, un, energy=en).mode == "RETURN_REQUIRED"
    assert AgentPolicy("D24R_NOSQ", B).step(0.0, np.zeros(3), np.zeros(3), pk, un, energy=en).mode != "RETURN_REQUIRED"


def test_batch_randomization_is_seed_paired_and_varies():
    import importlib.util
    import pathlib
    spec = importlib.util.spec_from_file_location(
        "ral26_batch", pathlib.Path(__file__).resolve().parents[1] / "scripts/swarm/ral26_batch.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)

    def cfg(seed, d):
        return {"swarm": {"num_uavs": 6}, "experiment": {"seed": seed}, "attack": {"id": "A14"},
                "defense": {"id": d}, "ral26": {"route": [20.0, 0.0], "randomize": {"on": True}}}
    a, b, c = cfg(5, "D24R"), cfg(5, "D26"), cfg(6, "D26")
    da, db, dc = m.randomize_scenario(a), m.randomize_scenario(b), m.randomize_scenario(c)
    assert da == db and da != dc
    assert abs(math.hypot(*a["ral26"]["route"]) - 20.0) < 1e-9
    assert a["ral26"]["attacker_id"] == da["attacker_id"]
    ids = {m.randomize_scenario(cfg(s, "D26"))["attacker_id"] for s in range(40)}
    assert len(ids) == 6
