#!/usr/bin/env python3
"""Dependency-free test runner (the DroneLab image ships no pytest).

    docker run --rm -v "$PWD:/workspace" dronelab:research-v1.17 \
        bash -lc 'cd /workspace && python tests/run_tests.py'
"""

import importlib
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

MODULES = ["tests.test_core", "tests.test_attacks", "tests.test_defenses",
           "tests.test_observation_authority", "tests.test_ral_integration",
           "tests.test_ral26_core", "tests.test_le", "tests.test_resilience", "tests.test_resilience_v2", "tests.test_resilience_v3"]


def main() -> int:
    passed = failed = 0
    for modname in MODULES:
        try:
            mod = importlib.import_module(modname)
        except ModuleNotFoundError as exc:   # a missing REQUIRED module is a failure, never a silent skip
            print(f"FAIL {modname}: required test module/import missing ({exc})")
            failed += 1
            continue
        for name in sorted(dir(mod)):
            if not name.startswith("test_"):
                continue
            fn = getattr(mod, name)
            if not callable(fn):
                continue
            try:
                fn()
                print(f"PASS {modname}.{name}")
                passed += 1
            except Exception:
                print(f"FAIL {modname}.{name}")
                traceback.print_exc()
                failed += 1
    print(f"\n{passed} passed, {failed} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
