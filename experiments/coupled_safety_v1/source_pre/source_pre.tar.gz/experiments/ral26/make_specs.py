#!/usr/bin/env python3
"""Generate the frozen RAL26 experiment specs (HF2/HF3/HF6).  Seed sets are disjoint:
pilot = 100.., final/confirmatory = 200.. (HF3), 300.. (HF6)."""
import json
from pathlib import Path

HERE = Path(__file__).parent
BASE = "config/swarm/ral26_base.toml"


def atk(aid, eps=0.0, beta=0.0, bv=0.0):
    return {"attack": {"id": aid}, "ral26": {"attack": {"epsilon": eps, "beta_attack": beta,
                                                         "beta_v_attack": bv}}}


def merge(*ds):
    out = {}
    for d in ds:
        for k, v in d.items():
            if isinstance(v, dict) and isinstance(out.get(k), dict):
                out[k] = merge(out[k], v)
            else:
                out[k] = v
    return out


HF2_CELLS = {
    "A0": atk("A0"),
    "A8_e1.0": atk("A8", 1.0), "A8_e2.5": atk("A8", 2.5),
    "A4_b1.25": atk("A4", 0, 1.25, 0.5), "A4_b2.5": atk("A4", 0, 2.5, 0.5), "A4_b6.25": atk("A4", 0, 6.25, 0.5),
    "A5": atk("A5"),
    "A14_e2.5_b1.25": atk("A14", 2.5, 1.25, 0.5), "A14_e2.5_b2.5": atk("A14", 2.5, 2.5, 0.5),
    "A14_e2.5_b6.25": atk("A14", 2.5, 6.25, 0.5), "A14_e1.0_b2.5": atk("A14", 1.0, 2.5, 0.5),
}


def hf2():
    eps = []
    for scen, cells in (("bottleneck", HF2_CELLS), ("breathing", {k: HF2_CELLS[k] for k in ("A0", "A14_e2.5_b2.5")})):
        for cell, ov in cells.items():
            for d in ("D0R", "D24R"):
                for s in (100, 101, 102):
                    eps.append({"name": f"{scen}_{cell}_{d}_s{s}",
                                "overrides": merge(ov, {"defense": {"id": d}, "experiment": {"seed": s},
                                                        "ral26": {"scenario": scen, "cell": f"{scen}_{cell}"}})})
    return {"tag": "hf2", "base": BASE, "common": {"swarm": {"num_uavs": 6}, "experiment": {"duration_s": 45.0}},
            "episodes": eps}


LEGACY_HYBRID = {"mode": "hybrid", "amp": 1.0, "onset_s": 0.0, "rho": 0.0, "dir": [1.0, 0.0, 0.0],
                 "closing_thresh": 1.0, "compression_thresh": -1.0, "density_thresh": 0.0, "k0": 1,
                 "lambda_thresh": 0.0, "period_s": 4.0, "duty": 1.0, "ramp_s": 1.0, "spoof": 1.0}


def legacy(defense, eps, beta, bv=0.5, attack="A13"):
    """Historical centralized controller (controllers/swarm/swarmsec_node.py, velocity mapping v=V+u*tau)
    on the same PX4/Gazebo X500 swarm, geometry and attack budgets; evaluated by the same isolated
    Gazebo-truth evaluator.  NOT information- or mission-matched to D24R/D26 (no route; central compute)."""
    params = {}
    if defense.startswith("D25"):
        params = {"beta_p": 1.25, "beta_v": 0.5, "u_max": 3.0, "hard_accel": 5.5, "track_bound": 3.2}
    return {"controller": {"mode": "legacy", "script": "swarmsec_node.py"},
            "control": {"kp": 0.9, "kv": 1.4, "max_speed_mps": 3.0, "velocity_tau_s": 0.5, "bootstrap_s": 3.0,
                        "arm_retry_s": 2.0, "land_timeout_s": 25.0},
            "safety": {"d_min": 1.5, "d_safe": 2.5, "k1": 2.0, "k2": 2.0, "u_max": 4.0},
            "mission": {"scenario": "bottleneck", "squeeze": 0.35, "vx_mps": 0.0, "vy_mps": 0.0, "vz_mps": 0.0},
            "attack": {"id": attack, "epsilon": eps, "start_s": 8.0,
                       "params": {**LEGACY_HYBRID, "beta_pos_m": beta, "beta_vel_mps": bv}},
            "defense": {"id": defense, "calib_key": "ideal", **({"params": params} if params else {})},
            "network": {"emulation": "ideal"}}


# ---- HF3: corrected comparison, preregistered after the HF2 pilot (seeds 200..209, disjoint from pilot)
HF3_CELLS = ("A0", "A14_e2.5_b1.25", "A14_e2.5_b2.5")
HF3_RAL = ("D24R_STATIC", "D24R", "D26")
HF3_LEGACY = ("D18N", "D24", "D25_COMM")


def hf3(seeds=range(200, 210), legacy_seeds=range(200, 205)):
    eps = []
    for cell in HF3_CELLS:
        ov = HF2_CELLS[cell]
        for d in HF3_RAL:
            for s in seeds:
                eps.append({"name": f"{cell}_{d}_s{s}", "overrides": merge(ov, {
                    "defense": {"id": d}, "experiment": {"seed": s},
                    "ral26": {"scenario": "bottleneck", "cell": f"bottleneck_{cell}"}})})
        a = ov["attack"]["id"]
        e = ov["ral26"]["attack"]["epsilon"]; b = ov["ral26"]["attack"]["beta_attack"]
        for d in HF3_LEGACY:
            for s in legacy_seeds:
                eps.append({"name": f"{cell}_LEGACY-{d}_s{s}", "overrides": merge(
                    legacy(d, e, b, attack="A0" if a == "A0" else "A13"),
                    {"experiment": {"seed": s}, "ral26": {"scenario": "bottleneck", "cell": f"bottleneck_{cell}"}})})
    return {"tag": "hf3", "base": BASE, "common": {"swarm": {"num_uavs": 6}, "experiment": {"duration_s": 45.0}},
            "episodes": eps}


# ---- HF6: joint adversarial-resource stress (seeds 300..309)
ADVERSE_NET = {"fanet": {"delay_s": 0.1, "jitter_s": 0.1, "loss": 0.15, "ge_p_gb": 0.05, "ge_p_bg": 0.3,
                         "t_net_max": 0.2},
               "bounds": {"T_net_max": 0.25},
               "outage": {"kind": "partition", "t0": 12.0, "dur": 3.0}}
HF6_REGIMES = {
    "R1_benign": merge(atk("A0"), {"ral26": {"energy": {"E0_wh": 60.0}}}),
    "R2_attack_net": merge(atk("A14", 2.5, 1.25, 0.5), {"ral26": {**ADVERSE_NET, "energy": {"E0_wh": 60.0}}}),
    "R3_attack_net_lowE": merge(atk("A14", 2.5, 1.25, 0.5), {"ral26": {**ADVERSE_NET, "energy": {"E0_wh": 5.0}}}),
}
HF6_VARIANTS = ("D24R", "D26_NOBATT", "D26_NOAOI", "D26_NOLINK", "D26")


def hf6(seeds=range(300, 310)):
    eps = []
    for reg, ov in HF6_REGIMES.items():
        for d in HF6_VARIANTS:
            for s in seeds:
                eps.append({"name": f"{reg}_{d}_s{s}", "overrides": merge(ov, {
                    "defense": {"id": d}, "experiment": {"seed": s},
                    "ral26": {"scenario": "bottleneck", "cell": reg, "route": [15.0, 0.0], "route_mode": "out_back"}})})
    return {"tag": "hf6", "base": BASE, "common": {"swarm": {"num_uavs": 6}, "experiment": {"duration_s": 55.0}},
            "episodes": eps}


# ---- follow-ups (priorities 1-3 of the request), seeds 400.. / 500.. / 600..
def hf2b(seeds=range(400, 405)):
    """Spoofing-budget sweep completion: D26 vs D24R at the far-outside-assumption budget beta 6.25."""
    eps = []
    for cell in ("A14_e2.5_b6.25", "A4_b6.25"):
        for d in ("D24R", "D26"):
            for sd in seeds:
                eps.append({"name": f"{cell}_{d}_s{sd}", "overrides": merge(HF2_CELLS[cell], {
                    "defense": {"id": d}, "experiment": {"seed": sd},
                    "ral26": {"scenario": "bottleneck", "cell": f"bottleneck_{cell}"}})})
    return {"tag": "hf2b", "base": BASE, "common": {"swarm": {"num_uavs": 6}, "experiment": {"duration_s": 45.0}},
            "episodes": eps}


def hf5(seeds=range(500, 503)):
    """Reachability / feasibility vs packet age: fractional subset of delay x loss (benign, so only the
    network moves the certificate), D24R vs D26.  T_net_max declared = delay + jitter + 0.05."""
    cells = [(0.0, 0.0), (0.1, 0.0), (0.2, 0.0), (0.0, 0.15), (0.0, 0.30), (0.1, 0.15), (0.2, 0.30)]
    eps = []
    for dl, ls in cells:
        net = {"fanet": {"delay_s": dl, "jitter_s": dl / 2, "loss": ls, "ge_p_gb": 0.05 if ls else 0.0,
                         "ge_p_bg": 0.3, "t_net_max": dl * 1.5 + 0.01},
               "bounds": {"T_net_max": dl * 1.5 + 0.05}}
        for d in ("D24R", "D26"):
            for sd in seeds:
                eps.append({"name": f"d{dl}_l{ls}_{d}_s{sd}", "overrides": merge(atk("A0"), {
                    "defense": {"id": d}, "experiment": {"seed": sd},
                    "ral26": {**net, "scenario": "bottleneck", "cell": f"d{dl}_l{ls}"}})})
    return {"tag": "hf5", "base": BASE, "common": {"swarm": {"num_uavs": 6}, "experiment": {"duration_s": 45.0}},
            "episodes": eps}


def adaptive_search(n_cfg=8, seeds=(600, 601), rng_seed=7):
    """Informed attacker (A14 family, eps 2.5, falsification within the defender's assumed bounds):
    random search over (trigger radius, onset, beta, beta_v) evaluated by real PX4 rollouts against D26;
    objective = min honest-attacker truth separation."""
    import random
    r = random.Random(rng_seed)
    eps = []
    for k in range(n_cfg):
        c = {"trigger_radius_m": r.choice([4.0, 6.0, 9.0, 12.0]), "start_s": r.choice([6.0, 10.0, 14.0, 18.0]),
             "beta_attack": r.choice([0.6, 1.0, 1.25]), "beta_v_attack": r.choice([0.0, 0.25, 0.5])}
        for sd in seeds:
            eps.append({"name": f"cfg{k}_D26_s{sd}", "meta": c, "overrides": merge(atk("A14", 2.5), {
                "defense": {"id": "D26"}, "experiment": {"seed": sd},
                "ral26": {"scenario": "bottleneck", "cell": f"cfg{k}", "attack": {"epsilon": 2.5, **c}}})})
    return {"tag": "adaptive_search", "base": BASE,
            "common": {"swarm": {"num_uavs": 6}, "experiment": {"duration_s": 45.0}}, "episodes": eps}


def adaptive_validate(best: dict, seeds=range(610, 615)):
    eps = []
    for d in ("D24R", "D26"):
        for sd in seeds:
            eps.append({"name": f"best_{d}_s{sd}", "meta": best, "overrides": merge(atk("A14", 2.5), {
                "defense": {"id": d}, "experiment": {"seed": sd},
                "ral26": {"scenario": "bottleneck", "cell": "adaptive_best", "attack": {"epsilon": 2.5, **best}}})})
    return {"tag": "adaptive_validate", "base": BASE,
            "common": {"swarm": {"num_uavs": 6}, "experiment": {"duration_s": 45.0}}, "episodes": eps}


# ---- v2 confirmatory campaign (pre-registered in experiments/ral26/PREREG_v2.md), seeds 900.. / 950..
# Fixes vs HF3/HF6: seed-randomised, defence-paired scenarios; compromised UAV runs a FIXED policy (D0R:
# commanded mission, no relaxation, no safety layer) and refuses refresh requests; truth at 50 Hz;
# static no-squeeze baselines inside the main comparison; stronger pursuit attacker A15.
V2_COMMON = {"swarm": {"num_uavs": 6}, "experiment": {"duration_s": 50.0},
             "ral26": {"truth_hz": 50.0,
                       "randomize": {"start_s": [8.0, 16.0], "trigger_radius_m": [6.0, 12.0],
                                     "squeeze_t0": [6.0, 10.0]},
                       "attack": {"attacker_policy": "D0R", "attacker_refuse_refresh": True}}}
V2_DEF = ("D0R", "D24R", "D24R_NOSQ", "D26")


def v2_main(seeds=range(900, 930), benign_seeds=range(900, 915)):
    cells = {"A0": (atk("A0"), benign_seeds),
             "A14_e2.5_b1.25": (atk("A14", 2.5, 1.25, 0.5), seeds),
             "A15_e2.5_b1.25": (atk("A15", 2.5, 1.25, 0.5), seeds)}
    eps = []
    for sd in seeds:                       # seed-major order: partial runs stay paired across defences
        for cell, (ov, ss) in cells.items():
            if sd not in ss:
                continue
            for d in V2_DEF:
                eps.append({"name": f"{cell}_{d}_s{sd}", "overrides": merge(ov, {
                    "defense": {"id": d}, "experiment": {"seed": sd},
                    "ral26": {"scenario": "bottleneck", "cell": cell}})})
    return {"tag": "v2_main", "base": BASE, "common": V2_COMMON, "episodes": eps}


def v2_sender_err(seeds=range(900, 915)):
    """Sensitivity: honest-sender estimate error added to the envelope (B_p += 0.6 m, B_v += 0.6 m/s)."""
    eps = []
    for sd in seeds:
        for d in ("D24R", "D24R_NOSQ", "D26"):
            eps.append({"name": f"SE_A14_e2.5_b1.25_{d}_s{sd}", "overrides": merge(atk("A14", 2.5, 1.25, 0.5), {
                "defense": {"id": d}, "experiment": {"seed": sd},
                "ral26": {"scenario": "bottleneck", "cell": "SE_A14_e2.5_b1.25",
                          "bounds": {"sender_err_p": 0.6, "sender_err_v": 0.6}}})})
    return {"tag": "v2_sender_err", "base": BASE, "common": V2_COMMON, "episodes": eps}


def v2_resource(seeds=range(950, 965)):
    """Adverse FANET (+ low energy) with the fair energy baseline and a mission window long enough to
    finish (95 s)."""
    regs = {"R2_attack_net": merge(atk("A14", 2.5, 1.25, 0.5), {"ral26": {**ADVERSE_NET, "energy": {"E0_wh": 60.0}}}),
            "R3_attack_net_lowE": merge(atk("A14", 2.5, 1.25, 0.5), {"ral26": {**ADVERSE_NET, "energy": {"E0_wh": 5.0}}})}
    eps = []
    for sd in seeds:
        for reg, ov in regs.items():
            for d in ("D24R_NOSQ", "D24R_NOSQ_BATT", "D26"):
                eps.append({"name": f"{reg}_{d}_s{sd}", "overrides": merge(ov, {
                    "defense": {"id": d}, "experiment": {"seed": sd},
                    "ral26": {"scenario": "bottleneck", "cell": reg, "route": [15.0, 0.0], "route_mode": "out_back"}})})
    common = merge(V2_COMMON, {"experiment": {"duration_s": 95.0}})
    return {"tag": "v2_resource", "base": BASE, "common": common, "episodes": eps}


if __name__ == "__main__" and len(__import__("sys").argv) > 1 and __import__("sys").argv[1] == "v2":
    for name, fn in (("v2_main", v2_main), ("v2_sender_err", v2_sender_err), ("v2_resource", v2_resource)):
        if not (HERE / f"{name}.json").exists():
            json.dump(fn(), open(HERE / f"{name}.json", "w"), indent=1)
        print(name, len(fn()["episodes"]))
    raise SystemExit(0)

if __name__ == "__main__":
    for name, fn in (("hf2b", hf2b), ("hf5", hf5), ("adaptive_search", adaptive_search)):
        if not (HERE / f"{name}.json").exists():
            json.dump(fn(), open(HERE / f"{name}.json", "w"), indent=1)
            print(name, len(fn()["episodes"]))
    for name, fn in (("hf2", hf2), ("hf3", hf3), ("hf6", hf6)):
        spec = fn()
        if name == "hf2" and (HERE / "hf2.json").exists():
            continue                                  # frozen: never regenerate a running/finished spec
        json.dump(spec, open(HERE / f"{name}.json", "w"), indent=1)
        print(name, len(spec["episodes"]))
