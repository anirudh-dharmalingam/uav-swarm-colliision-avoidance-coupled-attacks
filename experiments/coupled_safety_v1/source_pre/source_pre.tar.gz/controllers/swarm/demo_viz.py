#!/usr/bin/env python3
"""Demo overlay (scripts/demo): makes attack, defence and resilience visible in the Gazebo window, and
streams the same state to the Swarm Lab panel.

Observer only, like the truth evaluator: it reads Gazebo ground truth (/world/default/dynamic_pose/info)
and the controllers' own per-tick logs, and never publishes to the swarm.

Visual language (gz_draw primitives; ogre2 has no text/arrow markers, so both are drawn from triangles):
  every UAV     sphere + dot-matrix label: role and defence state (CERT / UNCERT / EMERG / LEADER / ...)
  attacker      red; red PUSH arrow = its malicious acceleration (command minus nominal); translucent GHOST
                sphere + dashed line = where it claims to be (spoofed report); dashed TRIGGER ring; red danger
                disc (1.5 m) while the attack is active
  defence       green arrow on an honest UAV = the safety filter's correction (command minus nominal);
                purple ring = quarantined / impeached; gold = leader, gold line = where the leader steers
                (red when a compromised leader steers)
  swarm         honest neighbour links coloured by separation (green >= 2.5 m, orange >= 1.5 m, red below),
                trails, route and keep-outs, HUD billboard with defence vs attack, separations, verdict
  moments       flash labels: ATTACK STARTS, CLOSE APPROACH, CONTACT, CRASH, IMPEACHED, QUARANTINED

Outputs <run>/live/hist.jsonl (5 Hz rows for the panel graphs), events.jsonl, final.json.

    python3 demo_viz.py --run-dir /workspace/results/demo_px4/<id>
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import math
import threading
import time
from pathlib import Path

import gz_draw as D
from gz_stream import GzStream, model_poses, stamp_s

CONTACT_M = 0.77          # X500 rotor-tip envelope: bodies touch at ~0.77 m centre distance
THRESH_M = 1.5            # the study's close-approach threshold
ARROW_GAIN = 0.9          # metres of arrow per m/s^2

C = {"att": (1.0, 0.08, 0.08), "att_idle": (0.55, 0.12, 0.12), "ghost": (1.0, 0.45, 0.45),
     "cert": (0.1, 0.85, 0.25), "uncert": (1.0, 0.85, 0.0), "emerg": (0.9, 0.15, 0.9), "return": (0.0, 0.8, 0.9),
     "nofilter": (0.3, 0.5, 1.0), "ok": (0.3, 0.6, 1.0), "quar": (0.6, 0.2, 1.0), "leader": (1.0, 0.72, 0.0),
     "cand": (0.6, 0.85, 1.0), "follower": (0.3, 0.55, 1.0), "idle": (0.6, 0.6, 0.6), "white": (1, 1, 1),
     "corr": (0.1, 0.95, 0.3), "safe": (0.1, 0.85, 0.25), "warn": (1.0, 0.6, 0.0), "bad": (1.0, 0.1, 0.1)}
LABEL = {"cert": "CERT", "uncert": "UNCERT", "emerg": "EMERG", "return": "RETURN", "nofilter": "NO FILTER",
         "ok": "OK", "quar": "QUARANTINED", "leader": "LEADER", "cand": "CANDIDATE", "follower": "FOLLOW",
         "idle": ""}
ATTACK_TXT = {"A0": "NO ATTACK", "A1": "RANDOM NOISE", "A2": "CONSTANT BIAS", "A3": "PERIODIC", "A4": "SPOOF",
              "A5": "REPLAY", "A6": "FIXED TRIGGER", "A7": "LEARNED", "A8": "MARGIN PUSH", "A9": "STEALTH RAMP",
              "A10": "WHITEBOX EVADER", "A12": "INNOVATION EVADER", "A13": "RANDOMISED", "A14": "PUSH+SPOOF",
              "A15": "PURSUIT", "L0": "NO ATTACK", "LINF": "INFLATE CLAIMS", "LTERM": "TERM FLOOD",
              "LFORGE": "FORGE LEADERSHIP", "LDEF": "DEFAME RIVALS", "LEQUIV": "EQUIVOCATE", "LSPOOF": "SPOOF POSITION",
              "LSPOOFS": "ADAPTIVE SPOOF", "LSTEER": "INSIDER STEERS", "LSTEALTH": "STEALTH STEER",
              "LSEL": "SELECTIVE SILENCE", "LCOMBO": "COMBINED", "LBURST": "TIMED BURST"}


class CsvTail:
    """Incrementally read a CSV that another process is appending to."""

    def __init__(self, path: Path):
        self.path, self.fh, self.header, self.buf, self.last = path, None, None, "", None

    def poll(self):
        if self.fh is None:
            if not self.path.exists():
                return self.last
            self.fh = self.path.open("r", newline="")
        chunk = self.fh.read()
        if not chunk:
            return self.last
        self.buf += chunk
        lines = self.buf.split("\n")
        self.buf = lines.pop()
        for ln in lines:
            if not ln.strip():
                continue
            vals = next(csv.reader(io.StringIO(ln)))
            if self.header is None:
                self.header = vals
            elif len(vals) == len(self.header):
                self.last = dict(zip(self.header, vals))
        return self.last


class JsonlTail(CsvTail):
    def poll(self):
        if self.fh is None:
            if not self.path.exists():
                return self.last
            self.fh = self.path.open("r")
        chunk = self.fh.read()
        if chunk:
            self.buf += chunk
            lines = self.buf.split("\n")
            self.buf = lines.pop()
            for ln in reversed(lines):
                if ln.strip():
                    try:
                        self.last = json.loads(ln)
                        break
                    except ValueError:
                        pass
        return self.last


def fnum(d, k, default=0.0):
    try:
        v = float(d.get(k))
        return v if v == v else default
    except (TypeError, ValueError):
        return default


def tilt_deg(q):
    c = max(-1.0, min(1.0, 1.0 - 2.0 * (q[0] * q[0] + q[1] * q[1])))
    return math.degrees(math.acos(c))


class Viz:
    def __init__(self, run_dir: Path):
        self.rd = run_dir
        self.sc = json.loads((run_dir / "scenario.json").read_text())
        import tomllib
        self.cfg = tomllib.loads((run_dir / "config.toml").read_text())
        self.n = int(self.sc["n"])
        self.study = self.sc.get("study", "ral26")
        self.att_cfg = int(self.sc.get("attacker_id", -1))
        self.attack, self.defense = str(self.sc.get("attack", "")), str(self.sc.get("defense", ""))
        self.yaw = float(self.cfg.get("demo", {}).get("yaw_cam", 0.785))
        ag = run_dir / "agents"
        if self.study == "stack":
            self.frames = JsonlTail(ag / "stack_frames.jsonl")
        else:
            name = "le_agent_{}.csv" if self.study == "le" else "agent_{}.csv"
            self.tails = {i: CsvTail(ag / name.format(i)) for i in range(self.n)}
        R = self.cfg.get("ral26", {})
        self.trig_r = float(R.get("attack", {}).get("trigger_radius_m", 0.0) or 0.0) if self.study == "ral26" else 0.0
        self.radius = float(self.cfg.get("formation", {}).get("neighbor_radius_m", 12.0))
        self.pos, self.tilt, self.sim = {}, {}, None
        self.lock = threading.Lock()
        self.trail = {i: [] for i in range(self.n)}
        self.prev, self.min_ha, self.min_hh = {}, math.inf, math.inf
        self.seen_att, self.flash = set(), []
        self.crashed, self.below, self.contact, self.t_first = set(), False, False, None
        self.att_on_prev, self.att_time, self.leader_prev, self.q_prev = False, 0.0, None, set()
        (run_dir / "live").mkdir(exist_ok=True)
        self.hist = (run_dir / "live" / "hist.jsonl").open("a")
        self.evf = (run_dir / "live" / "events.jsonl").open("a")
        self.stream = GzStream("/world/default/dynamic_pose/info", self._on_pose)
        self.pump = D.Pump()
        self.markers_ok, self.static_at, self.hud_at, self.cam_at, self.cam_c = None, -1e9, -1e9, -1e9, None
        self.latest, self.stop = None, False

    # ---- inputs -----------------------------------------------------------------------------------
    def _on_pose(self, msg):
        poses = model_poses(msg)
        if poses:
            with self.lock:
                self.sim = stamp_s(msg)
                for k, (p, q) in poses.items():
                    self.pos[k] = p
                    self.tilt[k] = tilt_deg(q)

    def event(self, t, kind, flash=None, where=None, color=None, **kw):
        self.evf.write(json.dumps({"t": round(t, 2), "event": kind, **kw}) + "\n")
        self.evf.flush()
        if flash and where is not None:
            self.flash.append((time.monotonic() + 4.0, flash, where, color or C["white"]))

    def view(self):
        """Per-UAV normalised state for all three studies."""
        U = {i: {"cat": "idle", "push": None, "corr": None, "ghost": None, "ring": None, "leader": False,
                 "steer": None, "att": False, "on": False} for i in range(self.n)}
        info = {}
        if self.study == "stack":
            f = self.frames.poll()
            if f:
                a, on = int(f.get("att", -1)), bool(f.get("on"))
                q = set(f.get("q") or [])
                st = f.get("status")
                for i in range(self.n):
                    du = (f["u"][i][0] - f["unom"][i][0], f["u"][i][1] - f["unom"][i][1])
                    u = U[i]
                    if i == a and self.attack != "A0":
                        u.update(att=True, on=on, push=du if on else None)
                        dr = (f["rep"][i][0] - f["pos"][i][0], f["rep"][i][1] - f["pos"][i][1])
                        if math.hypot(*dr) > 0.25:
                            u["ghost"] = dr
                    else:
                        u["cat"] = ("quar" if i in q else
                                    ("cert" if str(st[i]).startswith("CERTIFIED") else "uncert") if st else "ok")
                        u["corr"] = du
                    if i in q:
                        u["ring"] = "quar"
                info = {"q": sorted(q), "sus": f.get("sus"), "ev": f.get("ev"), "t_ctrl": f.get("t")}
            return U, info
        rows = {i: self.tails[i].poll() for i in range(self.n)}
        for i, s in rows.items():
            if not s:
                continue
            u = U[i]
            if self.study == "le":
                role = s.get("role")
                u["leader"] = role == "2"
                u["cat"] = "leader" if role == "2" else "cand" if role == "1" else "follower"
                if s.get("att") == "1":
                    self.seen_att.add(i)
                if i in self.seen_att:
                    u.update(att=True, on=s.get("att") == "1")
                if u["leader"]:
                    u["steer"] = (fnum(s, "crx"), fnum(s, "cry"))
            else:
                du = (fnum(s, "ux") - fnum(s, "unx"), fnum(s, "uy") - fnum(s, "uny"))
                if i == self.att_cfg:
                    on = s.get("attack_on") == "1"
                    u.update(att=True, on=on, push=du if on else None)
                    dr = (fnum(s, "rpx") - fnum(s, "px"), fnum(s, "rpy") - fnum(s, "py"))
                    if math.hypot(*dr) > 0.25:
                        u["ghost"] = dr
                else:
                    mode, st = s.get("mode", ""), s.get("status", "")
                    u["cat"] = ("return" if mode == "RETURN" else "emerg" if mode == "EMERGENCY" else
                                "nofilter" if st == "NO_FILTER" else "cert" if st.startswith("CERTIFIED") else "uncert")
                    u["corr"] = du if st != "NO_FILTER" else None
                    u["relax"], u["gamma"] = fnum(s, "relax"), fnum(s, "gamma", math.nan)
        if self.study == "le":
            votes = [rows[i].get("leader") for i in rows if rows[i] and i not in self.seen_att]
            votes = [v for v in votes if v not in (None, "-1")]
            info["leader"] = int(max(set(votes), key=votes.count)) if votes else -1
            info["distrust"] = sum(int(fnum(rows[i], "n_distrust")) for i in rows if rows[i])
        return U, info

    # ---- one telemetry tick -------------------------------------------------------------------------
    def step(self):
        U, info = self.view()
        with self.lock:
            pos, tilt, sim = dict(self.pos), dict(self.tilt), self.sim
        if sim is None or not pos:
            return None
        if self.t_first is None:
            self.t_first = sim
        t = sim - self.t_first
        att = {i for i, u in U.items() if u["att"]}
        att_on = any(U[i]["on"] for i in att)
        air = {i for i in pos if pos[i][2] > 1.0}
        hon = [i for i in range(self.n) if i not in att and i in pos]
        hh = [(math.dist(pos[i], pos[j]), i, j) for k, i in enumerate(hon) for j in hon[k + 1:] if i in air and j in air]
        ha = [(math.dist(pos[a], pos[j]), a, j) for a in att if a in air and a in pos for j in hon if j in air]
        cur_hh, cur_ha = (min(hh) if hh else None), (min(ha) if ha else None)
        if cur_hh:
            self.min_hh = min(self.min_hh, cur_hh[0])
        if cur_ha:
            self.min_ha = min(self.min_ha, cur_ha[0])
        if att_on and self.att_on_prev:
            self.att_time += 0.2
        # narrated moments
        for a in att:
            if a in pos and U[a]["on"] and not self.att_on_prev:
                self.event(t, "attack_on", f"{a} ATTACK STARTS", pos[a], C["att"], uav=a)
            if a in pos and self.att_on_prev and not att_on and self.study != "le":
                self.event(t, "attack_off", "ATTACK STOPPED", pos[a], C["white"], uav=a)
        self.att_on_prev = att_on
        worst = min([x for x in (cur_ha, cur_hh) if x], default=None)
        if worst and worst[0] < THRESH_M and not self.below:
            mid = tuple((pos[worst[1]][k] + pos[worst[2]][k]) / 2 for k in range(3))
            self.event(t, "close_approach", f"CLOSE {worst[0]:.1f}M", mid, C["warn"], a=worst[1], b=worst[2],
                       sep=round(worst[0], 2))
        self.below = bool(worst and worst[0] < THRESH_M)
        if worst and worst[0] < CONTACT_M and not self.contact:
            self.event(t, "contact", "CONTACT!", pos[worst[1]], C["bad"], a=worst[1], b=worst[2], sep=round(worst[0], 2))
        self.contact = bool(worst and worst[0] < CONTACT_M) or self.contact
        for i, v in tilt.items():
            if v > 60.0 and i not in self.crashed:
                self.crashed.add(i)
                self.event(t, "crash", f"{i} CRASH", pos[i], C["bad"], uav=i, tilt=round(v, 1))
        if self.study == "le":
            ld = info.get("leader", -1)
            if self.leader_prev is not None and ld != self.leader_prev:
                if self.leader_prev in self.seen_att and self.leader_prev in pos:
                    self.event(t, "impeached", f"{self.leader_prev} IMPEACHED", pos[self.leader_prev], C["quar"],
                               uav=self.leader_prev)
                elif ld >= 0 and ld in pos:
                    self.event(t, "new_leader", f"{ld} ELECTED", pos[ld], C["leader"], uav=ld)
            self.leader_prev = ld
        if self.study == "stack":
            q = set(info.get("q", []))
            for i in q - self.q_prev:
                if i in pos:
                    ok = i in att
                    self.event(t, "quarantine", f"{i} QUARANTINED" if ok else f"{i} FALSE ALARM", pos[i],
                               C["quar"] if ok else C["warn"], uav=i, correct=ok)
            self.q_prev = q
        for i, u in U.items():
            key = (u["cat"], u["on"], u["leader"])
            if self.prev.get(i) not in (None, key) and self.prev[i][0] != u["cat"]:
                self.evf.write(json.dumps({"t": round(t, 2), "event": "state", "uav": i,
                                           "change": {"state": [self.prev[i][0], u["cat"]]}}) + "\n")
            self.prev[i] = key
        row = {"t": round(t, 2), "sim": round(sim, 2), "att": sorted(att), "att_on": att_on,
               "pos": {i: [round(c, 2) for c in p] for i, p in pos.items()},
               "tilt": {i: round(v, 1) for i, v in tilt.items()},
               "min_hh": cur_hh[0] if cur_hh else None, "min_ha": cur_ha[0] if cur_ha else None,
               "run_min_hh": None if math.isinf(self.min_hh) else self.min_hh,
               "run_min_ha": None if math.isinf(self.min_ha) else self.min_ha,
               "cat": {i: U[i]["cat"] for i in U}, "info": info,
               "relax": {i: U[i]["relax"] for i in U if U[i].get("relax") is not None},
               "gamma": {i: U[i]["gamma"] for i in U if U[i].get("gamma") is not None and U[i]["gamma"] == U[i]["gamma"]},
               "corr": {i: round(math.hypot(*U[i]["corr"]), 2) for i in U if U[i]["corr"]},
               "push": {i: round(math.hypot(*U[i]["push"]), 2) for i in U if U[i]["push"]},
               "att_time": round(self.att_time, 1), "crashed": sorted(self.crashed), "verdict": self.verdict()[0]}
        self.hist.write(json.dumps(row) + "\n")
        self.hist.flush()
        return row, U, info, pos, tilt, att, att_on, hh, ha

    # ---- drawing ----------------------------------------------------------------------------------
    def verdict(self):
        if self.crashed:
            return "CRASH", C["bad"]
        if self.min_ha < CONTACT_M or self.min_hh < CONTACT_M:
            return "CONTACT < 0.77 M", C["bad"]
        if self.min_ha < THRESH_M or self.min_hh < THRESH_M:
            return "NEAR MISS < 1.5 M", C["warn"]
        return "SAFE, NO APPROACH < 1.5 M", C["safe"]

    def hud_lines(self, row, info):
        t = row["t"]
        if self.study == "le":
            head = f"CADLE STUDY: {self.defense} VS {self.attack} {ATTACK_TXT.get(self.attack, '')}"
        elif self.study == "stack":
            head = f"STACK: {self.defense} VS {self.attack} {ATTACK_TXT.get(self.attack, '')}"
        else:
            A = self.cfg.get("ral26", {}).get("attack", {})
            head = (f"RAL26: {self.defense} VS {self.attack} {ATTACK_TXT.get(self.attack, '')}"
                    + (f" E{float(A.get('epsilon', 0)):g} B{float(A.get('beta_attack', 0)):g}" if self.attack != "A0" else ""))
        l2 = f"T {t:5.1f}S   N {self.n}   ATTACK {'ON' if row['att_on'] else 'OFF'}"
        ha = row["min_ha"]
        l3 = f"NOW  H-A {ha:.1f}M" if ha is not None else "NOW  H-A -"
        l3 += f"  H-H {row['min_hh']:.1f}M" if row["min_hh"] is not None else "  H-H -"
        l4 = "WORST  H-A " + (f"{self.min_ha:.2f}M" if not math.isinf(self.min_ha) else "-") + \
             "  H-H " + (f"{self.min_hh:.2f}M" if not math.isinf(self.min_hh) else "-")
        if self.study == "le":
            ld = info.get("leader", -1)
            bad = ld in row["att"]
            l5 = f"LEADER {ld if ld >= 0 else '-'}{' = ATTACKER!' if bad else ''}  ATTACKER ACTIVE {self.att_time:.0f}S"
        elif self.study == "stack":
            q = info.get("q", [])
            l5 = ("QUARANTINED " + ",".join(map(str, q))) if q else "NO QUARANTINE"
            l5 += f"  EVIDENCE {float(info.get('ev') or 0):.1f}"
        else:
            h = [c for i, c in row["cat"].items() if i not in row["att"]]
            l5 = f"CERTIFIED {h.count('cert')}/{len(h)}  EMERG {h.count('emerg')}  UNCERT {h.count('uncert')}"
        return [head, l2, l3, l4, l5]

    def draw(self, snap, full):
        row, U, info, pos, tilt, att, att_on, hh, ha = snap
        it = []
        for i in range(self.n):
            if i not in pos:
                continue
            x, y, z = pos[i]
            u = U[i]
            col = (C["att"] if u["on"] else C["att_idle"]) if u["att"] else C[u["cat"]]
            big = 0.6 if (u["att"] or u["leader"]) else 0.42
            it.append(D.marker("uav", i, "SPHERE", (x, y, z + 0.75), (big, big, big), col))
            if u["att"]:
                act = ATTACK_TXT.get(self.attack, self.attack) if u["on"] else "WAITING"
                if self.study == "le" and not u["on"]:
                    act = "LEADS" if u["leader"] else "IMPEACHED"
                lab = f"{i} ATTACKER\n{act}"
            else:
                lab = f"{i} {LABEL[u['cat']]}"
            it.append(D.text("lbl", i, lab, (x, y, z + 1.3), self.yaw, 0.42, col if u["att"] else C["white"]))
            tr = self.trail[i]
            if not tr or math.dist(tr[-1], (x, y, z)) > 0.25:
                tr.append((x, y, z))
                del tr[:-80]
            if len(tr) >= 2:
                it.append(D.marker("trail", i, "LINE_STRIP", color=C["att"] if u["att"] else (0.25, 0.25, 0.35),
                                   points=tr))
            # attack visuals
            if u["push"] is not None:
                it += D.arrow("push", i, (x, y, z + 0.75), (u["push"][0] * ARROW_GAIN, u["push"][1] * ARROW_GAIN),
                              C["att"], head=0.5, width=0.18)
            else:
                it += [D.delete("push", i), D.delete("push_h", i)]
            if u["ghost"] is not None:
                g = (x + u["ghost"][0], y + u["ghost"][1], z)
                it.append(D.marker("ghost", i, "SPHERE", g, (0.55, 0.55, 0.55), C["ghost"], 0.35))
                it.append(D.dashed_line("spoof", i, (x, y, z), g, C["ghost"]))
                it.append(D.text("ghost_l", i, "CLAIMED", (g[0], g[1], z + 0.45), self.yaw, 0.22, C["ghost"]))
            else:
                it += [D.delete("ghost", i), D.delete("spoof", i), D.delete("ghost_l", i)]
            if u["att"] and u["on"]:
                it.append(D.disc("danger", i, (x, y, z - 0.05), THRESH_M, C["att"], 0.22))
            else:
                it.append(D.delete("danger", i))
            if u["att"] and self.trig_r > 0 and self.attack in ("A8", "A14", "A15"):
                it.append(D.ring("trig", i, (x, y, z), self.trig_r, C["ghost"], dashed=True, n=60))
            else:
                it.append(D.delete("trig", i))
            # defence visuals
            c = u["corr"]
            if c is not None and math.hypot(*c) > 0.15:
                it += D.arrow("corr", i, (x, y, z + 0.75), (c[0] * ARROW_GAIN, c[1] * ARROW_GAIN), C["corr"])
            else:
                it += [D.delete("corr", i), D.delete("corr_h", i)]
            if u["ring"] == "quar" or (self.study == "le" and u["att"] and not u["leader"]):
                it.append(D.ring("quar", i, (x, y, z), 1.0, C["quar"]))
                it.append(D.ring("quar2", i, (x, y, z + 0.1), 1.1, C["quar"]))
            else:
                it += [D.delete("quar", i), D.delete("quar2", i)]
            if u["steer"] is not None:
                sx, sy = u["steer"]
                sc = C["att"] if u["att"] else C["leader"]
                it.append(D.dashed_line("steer", 0, (x, y, z), (sx, sy, z), sc, 0.4))
                it.append(D.marker("steer_pt", 0, "CYLINDER", (sx, sy, 0.05), (0.8, 0.8, 0.05), sc, 0.7))
                it.append(D.text("steer_l", 0, "LEADER STEERS HERE", (sx, sy, 0.6), self.yaw, 0.3, sc))
        if not any(U[i]["steer"] is not None for i in U):
            it += [D.delete("steer", 0), D.delete("steer_pt", 0), D.delete("steer_l", 0)]
        # cohesion links among honest UAVs, and the attacker -> nearest honest link
        bands = {"g": [], "o": [], "r": []}
        for d, i, j in hh:
            if d <= self.radius:
                bands["g" if d >= 2.5 else "o" if d >= THRESH_M else "r"] += [pos[i], pos[j]]
        for k, colr in (("g", (0.2, 0.75, 0.3)), ("o", C["warn"]), ("r", C["bad"])):
            it.append(D.marker("links_" + k, 0, "LINE_LIST", color=colr, alpha=0.8, points=bands[k])
                      if bands[k] else D.delete("links_" + k, 0))
        near = {}
        for d, a, j in ha:
            if a not in near or d < near[a][0]:
                near[a] = (d, j)
        for a in range(self.n):
            if a in near:
                d, j = near[a]
                colr = (0.2, 0.75, 0.3) if d >= 2.5 else C["warn"] if d >= THRESH_M else C["bad"]
                it.append(D.marker("halink", a, "LINE_LIST", color=colr, points=[pos[a], pos[j]]))
                mid = tuple((pos[a][k] + pos[j][k]) / 2 for k in range(3))
                it.append(D.text("halink_l", a, f"{d:.1f}M", (mid[0], mid[1], mid[2] + 0.2), self.yaw, 0.28, colr))
            else:
                it += [D.delete("halink", a), D.delete("halink_l", a)]
        now = time.monotonic()
        self.flash = [f for f in self.flash if f[0] > now]
        for k in range(8):
            if k < len(self.flash):
                _, txt, where, colr = self.flash[-1 - k]
                it.append(D.text("flash", k, txt, (where[0], where[1], where[2] + 2.3 + 0.7 * k), self.yaw, 0.5, colr))
            else:
                it.append(D.delete("flash", k))
        if full:
            it += self.hud(row, info, pos)
        return it

    def hud(self, row, info, pos):
        hon = [p for i, p in pos.items() if i not in row["att"]] or list(pos.values())
        cx = sum(p[0] for p in hon) / len(hon)
        cy = sum(p[1] for p in hon) / len(hon)
        ext = max([math.hypot(p[0] - cx, p[1] - cy) for p in hon] + [3.0])
        bx, by = cx + math.cos(self.yaw) * (ext + 2.0), cy + math.sin(self.yaw) * (ext + 2.0)   # behind the swarm
        lines = self.hud_lines(row, info)
        h, z0 = 0.62, 8.5
        width = max(len(s) for s in lines) * 6 * h / 7 + 1.0
        v, vc = self.verdict()
        return [D.panel("hud_bg", 0, (bx, by, z0 - 1.4), self.yaw, width, (len(lines) * 1.5) * h + 1.6),
                D.text("hud", 0, "\n".join(lines), (bx, by, z0), self.yaw, h, C["white"]),
                D.text("hud_v", 0, "SWARM: " + v, (bx, by, z0 - 1.15), self.yaw, 0.75, vc)]

    def static_markers(self):
        S, it = self.sc.get("static", {}), []
        rt = S.get("route", [])
        if len(rt) >= 2:
            it.append(D.marker("route", 0, "LINE_STRIP", color=(0.05, 0.05, 0.05), points=[(x, y, 0.05) for x, y in rt]))
            for k, (x, y) in enumerate(rt[1:]):
                it.append(D.marker("wp", k, "CYLINDER", (x, y, 0.05), (1.2, 1.2, 0.05), (0.1, 0.3, 0.9), 0.6))
            gx, gy = rt[-1]
            it.append(D.text("goal", 0, "GOAL", (gx, gy, 0.8), self.yaw, 0.6, (0.1, 0.3, 0.9)))
        for k, (cx, cy, r) in enumerate(S.get("keepout_circles", [])):
            it.append(D.marker("keepout_c", k, "CYLINDER", (cx, cy, 3.0), (2 * r, 2 * r, 6.0), (0.9, 0.1, 0.1), 0.18))
            it.append(D.text("keepout_l", k, "KEEP-OUT", (cx, cy, 6.3), self.yaw, 0.8, (0.9, 0.1, 0.1)))
        for k, (x0, x1, y0, y1) in enumerate(S.get("keepout_boxes", [])):
            it.append(D.marker("keepout_b", k, "BOX", ((x0 + x1) / 2, (y0 + y1) / 2, 3.0), (x1 - x0, y1 - y0, 6.0),
                               (0.9, 0.1, 0.1), 0.18))
            it.append(D.text("keepout_bl", k, "KEEP-OUT", ((x0 + x1) / 2, (y0 + y1) / 2, 6.3), self.yaw, 0.8,
                             (0.9, 0.1, 0.1)))
        return it

    def camera(self, pos):
        try:
            v = json.loads((self.rd / "live_view.json").read_text())
        except (OSError, ValueError):
            v = {}
        if not v.get("follow", True) or not pos:
            return
        ps = list(pos.values())
        cx = sum(p[0] for p in ps) / len(ps)
        cy = sum(p[1] for p in ps) / len(ps)
        ext = max([math.hypot(p[0] - cx, p[1] - cy) for p in ps] + [4.0])
        if self.cam_c is not None and math.hypot(cx - self.cam_c[0], cy - self.cam_c[1]) < 2.0:
            return
        self.cam_c = (cx, cy)
        d, pitch = 1.6 * ext + 9.0, 0.6
        self.pump.camera(cx - math.cos(self.yaw) * d * math.cos(pitch), cy - math.sin(self.yaw) * d * math.cos(pitch),
                         5.0 + d * math.sin(pitch), 0.0, pitch, self.yaw)

    def marker_loop(self):
        while not self.stop:
            snap = self.latest
            if snap is None:
                time.sleep(0.1)
                continue
            now = time.monotonic()
            full = now - self.hud_at > 0.5
            try:
                items = self.draw(snap, full)
            except Exception:
                import traceback
                traceback.print_exc()
                time.sleep(0.5)
                continue
            if full:
                self.hud_at = now
            if now - self.static_at > 10.0:
                items += self.static_markers()
                self.static_at = now
            ok = self.pump.send(items)
            if ok != self.markers_ok:
                print(f"[viz] Gazebo markers {'OK' if ok else 'not accepted (GUI not up yet?)'}"
                      f" ({'pump' if self.pump.p else 'gz CLI'})", flush=True)
                self.markers_ok = ok
                if not ok:
                    self.static_at = -1e9
            if ok and now - self.cam_at > 1.0:
                self.cam_at = now
                self.camera(snap[3])
            time.sleep(0.1 if ok else 2.0)

    def run(self):
        done = self.rd / "ros_stage_done"
        threading.Thread(target=self.marker_loop, daemon=True).start()
        while True:
            try:
                out = self.step()
            except Exception:                    # an observer must never stop on a bad row
                import traceback
                traceback.print_exc()
                out = None
            if out is not None:
                self.latest = out
            if done.exists():
                time.sleep(3.0)
                break
            time.sleep(0.2)
        self.stop = True
        summ = self.rd / "eval" / "summary.json"
        final = {"run_min_hh": None if math.isinf(self.min_hh) else self.min_hh,
                 "run_min_ha": None if math.isinf(self.min_ha) else self.min_ha, "verdict": self.verdict()[0],
                 "attacker_active_s": self.att_time, "crashed": sorted(self.crashed)}
        if summ.exists():
            final["evaluator"] = json.loads(summ.read_text())
        (self.rd / "live" / "final.json").write_text(json.dumps(final, indent=1))
        if self.latest is not None:                # leave the final picture and verdict on screen
            time.sleep(0.3)
            self.pump.send(self.draw(self.latest, True))
        self.stream.close()
        print("[viz] finished", json.dumps({k: final[k] for k in ("run_min_hh", "run_min_ha", "verdict")}), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True)
    a = ap.parse_args()
    Viz(Path(a.run_dir)).run()


if __name__ == "__main__":
    main()
