// Persistent Gazebo marker sender for the demo overlay (demo_viz.py / gz_draw.py).
// The `gz service` CLI costs ~0.4 s per call (process start-up); this keeps one gz-transport node open.
//
// stdin, one request per line:
//   M <gz.msgs.Marker_V in protobuf text format>     -> /marker_array
//   C <x> <y> <z> <roll> <pitch> <yaw>                 -> /gui/move_to/pose (camera)
// stdout: one line per request, "ok" or "fail".
//
// Build (done by scripts/demo/stage.sh, cached in .cache/swarmlab):
//   g++ -O2 -std=c++17 marker_pump.cc $(pkg-config --cflags --libs gz-transport13 gz-msgs10) -o marker_pump
#include <gz/msgs/boolean.pb.h>
#include <gz/msgs/gui_camera.pb.h>
#include <gz/msgs/marker_v.pb.h>
#include <gz/transport/Node.hh>
#include <google/protobuf/text_format.h>

#include <cmath>
#include <iostream>
#include <sstream>
#include <string>

int main()
{
  std::ios::sync_with_stdio(false);
  gz::transport::Node node;
  std::string line;
  while (std::getline(std::cin, line))
  {
    if (line.size() < 2)
      continue;
    bool ok = false;
    gz::msgs::Boolean rep;
    bool result = false;
    if (line[0] == 'M')
    {
      gz::msgs::Marker_V req;
      if (google::protobuf::TextFormat::ParseFromString(line.substr(2), &req))
        ok = node.Request("/marker_array", req, 2000u, rep, result) && result;
    }
    else if (line[0] == 'C')
    {
      std::istringstream in(line.substr(2));
      double x, y, z, r, p, yw;
      if (in >> x >> y >> z >> r >> p >> yw)
      {
        gz::msgs::GUICamera req;
        auto *pose = req.mutable_pose();
        pose->mutable_position()->set_x(x);
        pose->mutable_position()->set_y(y);
        pose->mutable_position()->set_z(z);
        // roll-pitch-yaw -> quaternion
        double cr = std::cos(r / 2), sr = std::sin(r / 2), cp = std::cos(p / 2), sp = std::sin(p / 2);
        double cy = std::cos(yw / 2), sy = std::sin(yw / 2);
        pose->mutable_orientation()->set_w(cr * cp * cy + sr * sp * sy);
        pose->mutable_orientation()->set_x(sr * cp * cy - cr * sp * sy);
        pose->mutable_orientation()->set_y(cr * sp * cy + sr * cp * sy);
        pose->mutable_orientation()->set_z(cr * cp * sy - sr * sp * cy);
        ok = node.Request("/gui/move_to/pose", req, 2000u, rep, result) && result;
      }
    }
    std::cout << (ok ? "ok" : "fail") << std::endl;
  }
  return 0;
}
