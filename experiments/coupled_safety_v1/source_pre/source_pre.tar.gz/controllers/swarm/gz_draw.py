"""Drawing primitives for Gazebo Harmonic markers (ogre2), used by the demo overlay (demo_viz.py).

ogre2 renders BOX / CYLINDER / SPHERE / LINE_* / POINTS / TRIANGLE_* markers but not TEXT or ARROW
(Ogre2Marker: "Invalid Marker type"), so text is drawn as a 5x7 dot-matrix font out of triangles on a
vertical plane facing a given azimuth, and arrows as a line shaft plus a triangle head. Every function
returns protobuf-text `marker { ... }` items for one gz.msgs.Marker_V request (service /marker_array).
"""
from __future__ import annotations

import itertools
import math

_SERIAL = {}                         # (ns, logical id) -> id currently drawn (point markers only)
_IDS = itertools.count(1_000_000)

FONT = {  # 5x7 dot matrix, '#' = lit (rows top -> bottom)
    'A': ['.###.', '#...#', '#...#', '#####', '#...#', '#...#', '#...#'],
    'B': ['####.', '#...#', '#...#', '####.', '#...#', '#...#', '####.'],
    'C': ['.####', '#....', '#....', '#....', '#....', '#....', '.####'],
    'D': ['####.', '#...#', '#...#', '#...#', '#...#', '#...#', '####.'],
    'E': ['#####', '#....', '#....', '####.', '#....', '#....', '#####'],
    'F': ['#####', '#....', '#....', '####.', '#....', '#....', '#....'],
    'G': ['.####', '#....', '#....', '#.###', '#...#', '#...#', '.####'],
    'H': ['#...#', '#...#', '#...#', '#####', '#...#', '#...#', '#...#'],
    'I': ['#####', '..#..', '..#..', '..#..', '..#..', '..#..', '#####'],
    'J': ['..###', '...#.', '...#.', '...#.', '...#.', '#..#.', '.##..'],
    'K': ['#...#', '#..#.', '#.#..', '##...', '#.#..', '#..#.', '#...#'],
    'L': ['#....', '#....', '#....', '#....', '#....', '#....', '#####'],
    'M': ['#...#', '##.##', '#.#.#', '#...#', '#...#', '#...#', '#...#'],
    'N': ['#...#', '##..#', '#.#.#', '#..##', '#...#', '#...#', '#...#'],
    'O': ['.###.', '#...#', '#...#', '#...#', '#...#', '#...#', '.###.'],
    'P': ['####.', '#...#', '#...#', '####.', '#....', '#....', '#....'],
    'Q': ['.###.', '#...#', '#...#', '#...#', '#.#.#', '#..#.', '.##.#'],
    'R': ['####.', '#...#', '#...#', '####.', '#.#..', '#..#.', '#...#'],
    'S': ['.####', '#....', '#....', '.###.', '....#', '....#', '####.'],
    'T': ['#####', '..#..', '..#..', '..#..', '..#..', '..#..', '..#..'],
    'U': ['#...#', '#...#', '#...#', '#...#', '#...#', '#...#', '.###.'],
    'V': ['#...#', '#...#', '#...#', '#...#', '#...#', '.#.#.', '..#..'],
    'W': ['#...#', '#...#', '#...#', '#.#.#', '#.#.#', '#.#.#', '.#.#.'],
    'X': ['#...#', '#...#', '.#.#.', '..#..', '.#.#.', '#...#', '#...#'],
    'Y': ['#...#', '#...#', '.#.#.', '..#..', '..#..', '..#..', '..#..'],
    'Z': ['#####', '....#', '...#.', '..#..', '.#...', '#....', '#####'],
    '0': ['.###.', '#...#', '#..##', '#.#.#', '##..#', '#...#', '.###.'],
    '1': ['..#..', '.##..', '..#..', '..#..', '..#..', '..#..', '.###.'],
    '2': ['.###.', '#...#', '....#', '...#.', '..#..', '.#...', '#####'],
    '3': ['####.', '....#', '....#', '.###.', '....#', '....#', '####.'],
    '4': ['...#.', '..##.', '.#.#.', '#..#.', '#####', '...#.', '...#.'],
    '5': ['#####', '#....', '####.', '....#', '....#', '#...#', '.###.'],
    '6': ['..##.', '.#...', '#....', '####.', '#...#', '#...#', '.###.'],
    '7': ['#####', '....#', '...#.', '..#..', '.#...', '.#...', '.#...'],
    '8': ['.###.', '#...#', '#...#', '.###.', '#...#', '#...#', '.###.'],
    '9': ['.###.', '#...#', '#...#', '.####', '....#', '...#.', '.##..'],
    ' ': ['.....', '.....', '.....', '.....', '.....', '.....', '.....'],
    '.': ['.....', '.....', '.....', '.....', '.....', '.....', '..#..'],
    ',': ['.....', '.....', '.....', '.....', '.....', '..#..', '.#...'],
    '-': ['.....', '.....', '.....', '.###.', '.....', '.....', '.....'],
    '_': ['.....', '.....', '.....', '.....', '.....', '.....', '#####'],
    ':': ['.....', '..#..', '..#..', '.....', '..#..', '..#..', '.....'],
    '/': ['....#', '....#', '...#.', '..#..', '.#...', '#....', '#....'],
    '%': ['##..#', '##..#', '...#.', '..#..', '.#...', '#..##', '#..##'],
    '=': ['.....', '.....', '#####', '.....', '#####', '.....', '.....'],
    '+': ['.....', '..#..', '..#..', '#####', '..#..', '..#..', '.....'],
    '>': ['#....', '.#...', '..#..', '...#.', '..#..', '.#...', '#....'],
    '<': ['....#', '...#.', '..#..', '.#...', '..#..', '...#.', '....#'],
    '(': ['...#.', '..#..', '.#...', '.#...', '.#...', '..#..', '...#.'],
    ')': ['.#...', '..#..', '...#.', '...#.', '...#.', '..#..', '.#...'],
    '!': ['..#..', '..#..', '..#..', '..#..', '..#..', '.....', '..#..'],
    '?': ['.###.', '#...#', '....#', '...#.', '..#..', '.....', '..#..'],
    '|': ['..#..', '..#..', '..#..', '..#..', '..#..', '..#..', '..#..'],
    '*': ['.....', '#.#.#', '.###.', '#####', '.###.', '#.#.#', '.....'],
}


_RECTS = {}


def _rects(ch):
    """Glyph as maximal rectangles: horizontal runs merged downward while the run repeats exactly."""
    ch = ch.upper()
    if ch in _RECTS:
        return _RECTS[ch]
    g = _glyph(ch)
    runs = []
    for r in range(7):
        c = 0
        while c < 5:
            if g[r * 5 + c] == "#":
                c0 = c
                while c < 5 and g[r * 5 + c] == "#":
                    c += 1
                runs.append((r, c0, c))
            else:
                c += 1
    out, used = [], set()
    for r, c0, c1 in runs:
        if (r, c0, c1) in used:
            continue
        r1 = r + 1
        while (r1, c0, c1) in runs:
            used.add((r1, c0, c1))
            r1 += 1
        out.append((r, r1, c0, c1))
    _RECTS[ch] = out
    return out


def _glyph(ch):
    return "".join(FONT.get(ch.upper(), FONT["?"]))


def _f(v):
    return f"{v:.2f}".rstrip("0").rstrip(".") if v == v else "0"


def _col(c, a=1.0):
    r, g, b = c
    s = f"r:{_f(r)} g:{_f(g)} b:{_f(b)} a:{_f(a)}"
    return f"material{{ambient{{{s}}} diffuse{{{s}}} emissive{{{s}}}}}"


def _pts(points):
    return " ".join(f"point{{x:{_f(p[0])} y:{_f(p[1])} z:{_f(p[2])}}}" for p in points)


def marker(ns, mid, typ, pos=(0, 0, 0), scale=(1, 1, 1), color=(1, 1, 1), alpha=1.0, points=(), quat=None,
           parent=None):
    q = "" if quat is None else f"orientation{{x:{quat[0]:.4f} y:{quat[1]:.4f} z:{quat[2]:.4f} w:{quat[3]:.4f}}}"
    par = f' parent:"{parent}"' if parent else ""
    pre = ""
    if not points:
        mid = mid + 1               # marker id 0 means "allocate a new marker" in MarkerManager
    else:
        # MarkerManager keeps the old geometry of a point marker that is modified, or deleted and re-added
        # under the same id (it appends), so every redraw gets a fresh id and the previous one is deleted
        pre = (delete(ns, mid) + " ") if (ns, mid) in _SERIAL else ""
        _SERIAL[(ns, mid)] = mid = next(_IDS)
    return pre + (f'marker{{action:ADD_MODIFY ns:"{ns}" id:{mid} type:{typ} visibility:GUI{par} '
            f"pose{{position{{x:{_f(pos[0])} y:{_f(pos[1])} z:{_f(pos[2])}}}{q}}} "
            f"scale{{x:{_f(scale[0])} y:{_f(scale[1])} z:{_f(scale[2])}}} {_col(color, alpha)} "
            f"{_pts(points)}}}")


def delete(ns, mid):
    mid = _SERIAL.pop((ns, mid), mid + 1)
    return f'marker{{action:DELETE_MARKER ns:"{ns}" id:{mid}}}'


def text(ns, mid, s, anchor, yaw, height=0.4, color=(1, 1, 1), align="center", alpha=1.0, lines_gap=1.5, parent=None):
    """Dot-matrix text on a vertical plane facing a camera at azimuth `yaw` (the direction the camera
    looks). `anchor` is the bottom-centre (align=center) or bottom-left of the LAST line; `s` may hold
    '\\n'. Horizontal runs of lit pixels are merged into one quad (2 triangles) to keep requests small."""
    px = height / 7.0
    rx, ry = math.sin(yaw), -math.cos(yaw)          # screen-right for a camera looking along (cos, sin)
    lines = s.split("\n")
    tris = []
    for li, ln in enumerate(lines):
        w = len(ln) * 6 * px
        x0 = -w / 2 if align == "center" else 0.0
        z0 = (len(lines) - 1 - li) * height * lines_gap
        for ci, ch in enumerate(ln):
            for (r0, r1, c0, c1) in _rects(ch):            # rows r0..r1-1, cols c0..c1-1 lit
                u0 = x0 + (ci * 6 + c0) * px
                u1 = x0 + (ci * 6 + c1) * px
                v1 = z0 + (7 - r0) * px
                v0 = z0 + (7 - r1) * px
                a = (anchor[0] + rx * u0, anchor[1] + ry * u0)
                b = (anchor[0] + rx * u1, anchor[1] + ry * u1)
                p00, p10 = (a[0], a[1], anchor[2] + v0), (b[0], b[1], anchor[2] + v0)
                p01, p11 = (a[0], a[1], anchor[2] + v1), (b[0], b[1], anchor[2] + v1)
                tris += [p00, p10, p11, p00, p11, p01]
    if not tris:
        return delete(ns, mid)
    return marker(ns, mid, "TRIANGLE_LIST", color=color, alpha=alpha, points=tris, parent=parent)


def panel(ns, mid, anchor, yaw, width, height, color=(0.05, 0.05, 0.08), alpha=0.75):
    """Backing quad for text (bottom-centre anchor), slightly behind the text plane."""
    rx, ry = math.sin(yaw), -math.cos(yaw)
    bx, by = -math.cos(yaw) * 0.05, -math.sin(yaw) * 0.05      # push away from the camera
    a = (anchor[0] - rx * width / 2 + bx, anchor[1] - ry * width / 2 + by)
    b = (anchor[0] + rx * width / 2 + bx, anchor[1] + ry * width / 2 + by)
    z0, z1 = anchor[2], anchor[2] + height
    p00, p10, p01, p11 = (a[0], a[1], z0), (b[0], b[1], z0), (a[0], a[1], z1), (b[0], b[1], z1)
    return marker(ns, mid, "TRIANGLE_LIST", color=color, alpha=alpha, points=[p00, p10, p11, p00, p11, p01])


def arrow(ns, mid, start, vec, color, head=0.35, min_len=0.05, width=0.12):
    """Filled flat arrow in the horizontal plane (shaft quad + head triangle, both faces)."""
    L = math.hypot(vec[0], vec[1])
    if L < min_len:
        return [delete(ns, mid), delete(ns + "_h", mid)]
    ux, uy = vec[0] / L, vec[1] / L
    nx, ny = -uy, ux
    z = start[2]
    h = min(head, 0.5 * L)
    tip = (start[0] + vec[0], start[1] + vec[1], z)
    base = (tip[0] - ux * h, tip[1] - uy * h, z)
    w, hw = width / 2, 0.6 * h

    def quad(p, q, r, t):
        return [p, q, r, p, r, t, p, r, q, p, t, r]
    shaft = quad((start[0] + nx * w, start[1] + ny * w, z), (start[0] - nx * w, start[1] - ny * w, z),
                 (base[0] - nx * w, base[1] - ny * w, z), (base[0] + nx * w, base[1] + ny * w, z))
    a, b = (base[0] + nx * hw, base[1] + ny * hw, z), (base[0] - nx * hw, base[1] - ny * hw, z)
    return [marker(ns, mid, "TRIANGLE_LIST", color=color, points=shaft),
            marker(ns + "_h", mid, "TRIANGLE_LIST", color=color, points=[tip, a, b, tip, b, a])]


def ring(ns, mid, centre, r, color, alpha=1.0, n=40, dashed=False):
    pts = [(centre[0] + r * math.cos(2 * math.pi * k / n), centre[1] + r * math.sin(2 * math.pi * k / n), centre[2])
           for k in range(n + 1)]
    if dashed:
        seg = []
        for k in range(0, n, 2):
            seg += [pts[k], pts[k + 1]]
        return marker(ns, mid, "LINE_LIST", color=color, alpha=alpha, points=seg)
    return marker(ns, mid, "LINE_STRIP", color=color, alpha=alpha, points=pts)


def disc(ns, mid, centre, r, color, alpha=0.25, n=32):
    tris = []
    for k in range(n):
        a0, a1 = 2 * math.pi * k / n, 2 * math.pi * (k + 1) / n
        p0 = (centre[0] + r * math.cos(a0), centre[1] + r * math.sin(a0), centre[2])
        p1 = (centre[0] + r * math.cos(a1), centre[1] + r * math.sin(a1), centre[2])
        tris += [tuple(centre), p0, p1, tuple(centre), p1, p0]          # both faces
    return marker(ns, mid, "TRIANGLE_LIST", color=color, alpha=alpha, points=tris)


def dashed_line(ns, mid, a, b, color, dash=0.25):
    L = math.dist(a, b)
    n = max(1, int(L / dash))
    pts = []
    for k in range(0, n, 2):
        t0, t1 = k / n, min(1.0, (k + 1) / n)
        pts += [tuple(a[j] + (b[j] - a[j]) * t0 for j in range(3)), tuple(a[j] + (b[j] - a[j]) * t1 for j in range(3))]
    return marker(ns, mid, "LINE_LIST", color=color, points=pts)


def send(items, limit=100_000, timeout_ms=2000):
    """Send marker items in as few /marker_array calls as fit under the argv size limit (128 KiB)."""
    import subprocess
    ok, batch, size = True, [], 0
    def flush(b):
        if not b:
            return True
        try:
            r = subprocess.run(["gz", "service", "-s", "/marker_array", "--reqtype", "gz.msgs.Marker_V",
                                "--reptype", "gz.msgs.Boolean", "--timeout", str(timeout_ms), "--req", " ".join(b)],
                               capture_output=True, text=True, timeout=timeout_ms / 1000 + 3)
            return "true" in r.stdout
        except Exception:
            return False
    for it in items:
        if size + len(it) > limit and batch:
            ok &= flush(batch)
            batch, size = [], 0
        batch.append(it)
        size += len(it) + 1
    ok &= flush(batch)
    return ok


class Pump:
    """Persistent sender (marker_pump.cc, ~ms per request); falls back to the `gz service` CLI."""

    def __init__(self, exe=None):
        import os
        import subprocess
        exe = exe or os.environ.get("DS_MARKER_PUMP", "/workspace/.cache/swarmlab/marker_pump")
        self.p = None
        if os.path.exists(exe):
            self.p = subprocess.Popen([exe], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1)

    def _call(self, line):
        try:
            self.p.stdin.write(line + "\n")
            self.p.stdin.flush()
            return self.p.stdout.readline().strip() == "ok"
        except Exception:
            self.p = None
            return False

    def send(self, items, limit=2_000_000):
        if self.p is None:
            return send(items)
        ok, batch, size = True, [], 0
        for it in items:
            if size + len(it) > limit and batch:
                ok &= self._call("M " + " ".join(batch))
                batch, size = [], 0
            batch.append(it)
            size += len(it) + 1
        if batch:
            ok &= self._call("M " + " ".join(batch))
        return ok

    def camera(self, x, y, z, roll, pitch, yaw):
        if self.p is None:
            return False
        return self._call(f"C {x:.2f} {y:.2f} {z:.2f} {roll:.3f} {pitch:.3f} {yaw:.3f}")
